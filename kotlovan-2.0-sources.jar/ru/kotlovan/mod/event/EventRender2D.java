package ru.kotlovan.mod.event;

import net.minecraft.class_437;

public class EventRender2D extends Event {
    private final float tickDelta;
    private final class_437 currentScreen;

    public EventRender2D(float tickDelta, class_437 currentScreen) {
        this.tickDelta = tickDelta;
        this.currentScreen = currentScreen;
    }

    public float getTickDelta() {
        return tickDelta;
    }

    public class_437 getCurrentScreen() {
        return currentScreen;
    }
}
