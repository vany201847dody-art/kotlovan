package ru.kotlovan.mod.event;

import net.minecraft.class_1159;
import net.minecraft.class_4587;

public class EventRender3D extends Event {
    private final class_4587 matrixStack;
    private final float tickDelta;
    private final long nanoTime;
    private final class_1159 projectionMatrix;

    public EventRender3D(class_4587 matrixStack, float tickDelta, long nanoTime, class_1159 projectionMatrix) {
        this.matrixStack = matrixStack;
        this.tickDelta = tickDelta;
        this.nanoTime = nanoTime;
        this.projectionMatrix = projectionMatrix;
    }

    public class_4587 getMatrixStack() {
        return matrixStack;
    }

    public float getTickDelta() {
        return tickDelta;
    }

    public long getNanoTime() {
        return nanoTime;
    }

    public class_1159 getProjectionMatrix() {
        return projectionMatrix;
    }
}
