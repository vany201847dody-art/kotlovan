package ru.kotlovan.mod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2585;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class KotlovanMod implements ClientModInitializer {

    private static final String CAT = "Котлован";

    public static class_304 NUKER_KEY;
    public static class_304 FLY_KEY;
    public static class_304 SPEED_KEY;
    public static class_304 SPRINT_KEY;
    public static class_304 NOFALL_KEY;
    public static class_304 KILLAURA_KEY;
    public static class_304 FULLBRIGHT_KEY;
    public static class_304 STEP_KEY;
    public static class_304 AIRJUMP_KEY;
    public static class_304 SPIDER_KEY;
    public static class_304 AUTOTOOL_KEY;
    public static class_304 INSTANT_KEY;
    public static class_304 GLIDE_KEY;
    public static class_304 LONGJUMP_KEY;
    public static class_304 CRITICALS_KEY;
    public static class_304 AUTOSWORD_KEY;
    public static class_304 FREECAM_KEY;
    public static class_304 CHESTSTEAL_KEY;
    public static class_304 HIDEHUD_KEY;
    public static class_304 PANIC_KEY;
    public static class_304 GUI_KEY;

    private static final KotlovanClient CLIENT = new KotlovanClient();
    private static boolean configLoaded = false;

    public static KotlovanClient client() {
        return CLIENT;
    }

    @Override
    public void onInitializeClient() {
        NUKER_KEY = reg("Nuker", GLFW.GLFW_KEY_R);
        FLY_KEY = reg("Fly", GLFW.GLFW_KEY_F);
        SPEED_KEY = reg("Speed", GLFW.GLFW_KEY_C);
        SPRINT_KEY = reg("AutoSprint", GLFW.GLFW_KEY_P);
        NOFALL_KEY = reg("NoFall", GLFW.GLFW_KEY_N);
        KILLAURA_KEY = reg("KillAura", GLFW.GLFW_KEY_H);
        FULLBRIGHT_KEY = reg("FullBright", GLFW.GLFW_KEY_V);
        STEP_KEY = reg("Step", GLFW.GLFW_KEY_U);
        AIRJUMP_KEY = reg("AirJump", GLFW.GLFW_KEY_J);
        SPIDER_KEY = reg("Spider", GLFW.GLFW_KEY_K);
        AUTOTOOL_KEY = reg("AutoTool", GLFW.GLFW_KEY_T);
        INSTANT_KEY = reg("InstantAttack", GLFW.GLFW_KEY_I);
        GLIDE_KEY = reg("Glide", GLFW.GLFW_KEY_G);
        LONGJUMP_KEY = reg("LongJump", GLFW.GLFW_KEY_B);
        CRITICALS_KEY = reg("Criticals", GLFW.GLFW_KEY_Y);
        AUTOSWORD_KEY = reg("AutoSword", GLFW.GLFW_KEY_LEFT_ALT);
        FREECAM_KEY = reg("Freecam", GLFW.GLFW_KEY_Z);
        CHESTSTEAL_KEY = reg("ChestStealer", GLFW.GLFW_KEY_X);
        HIDEHUD_KEY = reg("Скрыть HUD", GLFW.GLFW_KEY_INSERT);
        PANIC_KEY = reg("ТРЕВОГА", GLFW.GLFW_KEY_DELETE);
        GUI_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
                "Открыть ClickGUI", class_3675.class_307.field_1668, GLFW.GLFW_KEY_RIGHT_SHIFT, CAT));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (!configLoaded) {
                configLoaded = true;
                CLIENT.loadConfig();
            }
            if (mc.field_1687 == null || mc.field_1724 == null) return;
            CLIENT.tick();
            while (GUI_KEY.method_1436()) {
                if (mc.field_1755 == null) {
                    mc.method_1507(new ClickGuiScreen());
                }
            }
        });

        HudRenderCallback.EVENT.register(HudRenderer::render);
    }

    private static class_304 reg(String name, int key) {
        return KeyBindingHelper.registerKeyBinding(new class_304(name, class_3675.class_307.field_1668, key, CAT));
    }

    public static void chat(String msg) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            mc.field_1724.method_7353(new class_2585("§8[§6Котлован§8] §7" + msg), false);
        }
    }
}
