package ru.kotlovan.mod.module.impl;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import ru.kotlovan.mod.event.Event;
import ru.kotlovan.mod.event.EventRender3D;
import ru.kotlovan.mod.module.EventTarget;
import ru.kotlovan.mod.module.Module;
import ru.kotlovan.mod.module.ModuleInfo;
import ru.kotlovan.mod.setting.*;
import ru.kotlovan.mod.util.ColorUtils;
import ru.kotlovan.mod.util.RenderUtils;

@ModuleInfo(name = "ESP", category = "Render", description = "Видение игроков и мобов")
public class ESP extends Module {
    private final ModeSetting mode = new ModeSetting("Mode", "Boxes", "Boxes", "Skeletons", "Glow");
    private final BooleanSetting players = new BooleanSetting("Players", true);
    private final BooleanSetting mobs = new BooleanSetting("Mobs", false);
    private final BooleanSetting animals = new BooleanSetting("Animals", false);
    private final BooleanSetting wallhack = new BooleanSetting("Wallhack", true);
    private final NumberSetting range = new NumberSetting("Range", 64.0, 16.0, 256.0, 8.0);
    private final NumberSetting lineWidth = new NumberSetting("LineWidth", 2.0, 0.5, 5.0, 0.5);
    private final BooleanSetting rainbow = new BooleanSetting("Rainbow", true);
    private final ColorSetting boxColor = new ColorSetting("BoxColor", 0, 255, 0, 200);

    public ESP() {
        addSetting(mode);
        addSetting(players);
        addSetting(mobs);
        addSetting(animals);
        addSetting(wallhack);
        addSetting(range);
        addSetting(lineWidth);
        addSetting(rainbow);
        addSetting(boxColor);
    }

    @EventTarget(priority = Event.Priority.LOW)
    public void onRender3D(EventRender3D event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        float time = event.getTickDelta();
        int color = rainbow.isOn() ? ColorUtils.chroma(0, 3.0f, 1.0f, 1.0f) : boxColor.toInt();
        float r = (color >> 16 & 0xFF) / 255.0f;
        float g = (color >> 8 & 0xFF) / 255.0f;
        float b = (color & 0xFF) / 255.0f;

        class_238 searchBox = mc.field_1724.method_5829().method_1014(range.getValue());

        for (class_1297 entity : mc.field_1687.method_8390(class_1297.class, searchBox, e -> e instanceof class_1309)) {
            if (entity == mc.field_1724) continue;
            if (entity.field_5988) continue;
            if (!(entity instanceof class_1309)) continue;

            class_1309 living = (class_1309) entity;
            if (!players.isOn() && living instanceof class_1657) continue;
            if (!mobs.isOn() && living instanceof class_1569) continue;
            if (!animals.isOn() && living instanceof class_1429) continue;

            if (mode.is("Boxes")) {
                class_238 box = living.method_5829();
                RenderUtils.drawBox(event.getMatrixStack(), box, r, g, b, 0.8f);

                // Рамка сверху/снизу ярче
                RenderUtils.drawBox(event.getMatrixStack(),
                        box.field_1323, box.field_1325 - 0.05, box.field_1321,
                        box.field_1320, box.field_1325, box.field_1324,
                        r, g, b, 1.0f);

            } else if (mode.is("Skeletons")) {
                drawSkeleton(event.getMatrixStack(), living, r, g, b);

            } else if (mode.is("Glow")) {
                class_238 box = living.method_5829();
                float pulse = (float) (Math.sin(time * 4) * 0.15 + 0.85);
                RenderUtils.drawBox(event.getMatrixStack(), box,
                        r * pulse, g * pulse, b * pulse, 0.6f);
            }
        }
    }

    private void drawSkeleton(net.minecraft.class_4587 matrices, class_1309 entity, float r, float g, float b) {
        class_243 cam = mc.field_1773.method_19418().method_19326();
        double ex = entity.method_23317() - cam.field_1352;
        double ey = entity.method_23318() - cam.field_1351;
        double ez = entity.method_23321() - cam.field_1350;
        float hw = (float) (entity.method_17681() * 0.5);

        // Голова
        RenderUtils.drawLine(matrices, (float) ex, (float) (ey + entity.method_17682()), (float) ez,
                (float) ex, (float) (ey + entity.method_17682() - 0.2), (float) ez, r, g, b, 0.8f);

        // Тело
        RenderUtils.drawLine(matrices, (float) ex, (float) (ey + entity.method_17682() - 0.2), (float) ez,
                (float) ex, (float) (ey + entity.method_17682() * 0.5), (float) ez, r, g, b, 0.8f);

        // Руки
        RenderUtils.drawLine(matrices, (float) ex, (float) (ey + entity.method_17682() - 0.15), (float) ez,
                (float) (ex - hw), (float) (ey + entity.method_17682() * 0.45), (float) ez, r, g, b, 0.8f);
        RenderUtils.drawLine(matrices, (float) ex, (float) (ey + entity.method_17682() - 0.15), (float) ez,
                (float) (ex + hw), (float) (ey + entity.method_17682() * 0.45), (float) ez, r, g, b, 0.8f);

        // Ноги
        RenderUtils.drawLine(matrices, (float) ex, (float) (ey + entity.method_17682() * 0.5), (float) ez,
                (float) (ex - hw * 0.5f), (float) ey, (float) ez, r, g, b, 0.8f);
        RenderUtils.drawLine(matrices, (float) ex, (float) (ey + entity.method_17682() * 0.5), (float) ez,
                (float) (ex + hw * 0.5f), (float) ey, (float) ez, r, g, b, 0.8f);
    }
}
