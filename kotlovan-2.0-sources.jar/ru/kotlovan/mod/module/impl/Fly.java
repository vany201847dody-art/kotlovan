package ru.kotlovan.mod.module.impl;

import net.minecraft.class_2828;
import ru.kotlovan.mod.event.EventUpdate;
import ru.kotlovan.mod.module.EventTarget;
import ru.kotlovan.mod.module.Module;
import ru.kotlovan.mod.module.ModuleInfo;
import ru.kotlovan.mod.setting.ModeSetting;
import ru.kotlovan.mod.setting.NumberSetting;
import ru.kotlovan.mod.setting.BooleanSetting;

@ModuleInfo(name = "Fly", category = "Movement", description = "Полёт")
public class Fly extends Module {
    private final ModeSetting mode = new ModeSetting("Mode", "Vanilla", "Vanilla", "Packet", "MatrixBypass");
    private final NumberSetting speed = new NumberSetting("Speed", 2.0, 0.5, 10.0, 0.1);
    private final BooleanSetting antiKick = new BooleanSetting("AntiKick", true);

    private int tickCounter;
    private double startY;

    public Fly() {
        addSetting(mode);
        addSetting(speed);
        addSetting(antiKick);
    }

    @Override
    protected void onEnable() {
        tickCounter = 0;
        if (mc.field_1724 != null) {
            startY = mc.field_1724.method_23318();
        }
    }

    @Override
    protected void onDisable() {
        if (mc.field_1724 != null) {
            mc.field_1724.field_7503.field_7479 = false;
        }
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.field_1724 == null) return;

        mc.field_1724.field_7503.field_7479 = false;
        mc.field_1724.method_18799(mc.field_1724.method_18798().method_18805(0, 0, 0));

        double spd = speed.getValue();
        tickCounter++;

        if (mode.is("Vanilla")) {
            mc.field_1724.method_18800(
                    -Math.sin(Math.toRadians(mc.field_1724.field_6031)) * spd * mc.field_1724.field_3913.field_3905,
                    mc.field_1724.field_3913.field_3904 ? spd : (mc.field_1724.field_3913.field_3903 ? -spd : 0),
                    Math.cos(Math.toRadians(mc.field_1724.field_6031)) * spd * mc.field_1724.field_3913.field_3905
            );
        } else if (mode.is("Packet")) {
            double y = mc.field_1724.method_23318();
            if (antiKick.isOn() && tickCounter % 20 == 0) {
                y -= 0.04;
            }
            mc.field_1724.field_3944.method_2883(
                    new class_2828.class_2829(mc.field_1724.method_23317(), y, mc.field_1724.method_23321(), false)
            );
            mc.field_1724.field_3944.method_2883(
                    new class_2828.class_2829(mc.field_1724.method_23317(), y + 0.01, mc.field_1724.method_23321(), false)
            );
            mc.field_1724.method_5814(mc.field_1724.method_23317(), y, mc.field_1724.method_23321());
        } else if (mode.is("MatrixBypass")) {
            double y = mc.field_1724.method_23318();
            mc.field_1724.field_3944.method_2883(
                    new class_2828.class_2829(mc.field_1724.method_23317(), y, mc.field_1724.method_23321(), false)
            );
            if (tickCounter % 10 == 0) {
                mc.field_1724.field_3944.method_2883(
                        new class_2828.class_2829(mc.field_1724.method_23317(), y - 0.02, mc.field_1724.method_23321(), false)
                );
                mc.field_1724.method_5814(mc.field_1724.method_23317(), y - 0.02, mc.field_1724.method_23321());
            }
        }
    }
}
