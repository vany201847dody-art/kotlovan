package ru.kotlovan.mod.module.impl;

import ru.kotlovan.mod.event.Event;
import ru.kotlovan.mod.event.EventRender3D;
import ru.kotlovan.mod.event.EventUpdate;
import ru.kotlovan.mod.module.EventTarget;
import ru.kotlovan.mod.module.Module;
import ru.kotlovan.mod.module.ModuleInfo;
import ru.kotlovan.mod.setting.*;
import ru.kotlovan.mod.util.MathUtils;
import ru.kotlovan.mod.util.RenderUtils;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;

@ModuleInfo(name = "KillAura", category = "Combat", description = "Автоатака с плавным наведением")
public class KillAura extends Module {
    // Настройки
    private final ModeSetting targetMode = new ModeSetting("Target", "Single", "Single", "Switch");
    private final ModeSetting sorting = new ModeSetting("Sorting", "Distance", "Distance", "Health");
    private final BooleanSetting players = new BooleanSetting("Players", true);
    private final BooleanSetting mobs = new BooleanSetting("Mobs", true);
    private final BooleanSetting invisibles = new BooleanSetting("Invisibles", false);
    private final NumberSetting range = new NumberSetting("Range", 4.0, 2.0, 6.0, 0.1);
    private final BooleanSetting blockRaytrace = new BooleanSetting("BlockRaytrace", false);
    private final BooleanSetting shieldBreaker = new BooleanSetting("ShieldBreaker", true);
    private final NumberSetting minCPS = new NumberSetting("MinCPS", 10.0, 1.0, 20.0, 1.0);
    private final NumberSetting maxCPS = new NumberSetting("MaxCPS", 14.0, 1.0, 20.0, 1.0);
    private final NumberSetting rotationSpeed = new NumberSetting("RotationSpeed", 60.0, 10.0, 360.0, 5.0);
    private final BooleanSetting targetESP = new BooleanSetting("TargetESP", true);
    private final ColorSetting espColor = new ColorSetting("ESPColor", 255, 50, 50, 200);

    private class_1309 target;
    private float targetYaw, targetPitch;
    private float currentYaw, currentPitch;
    private long lastAttackTime;
    private int switchIndex;
    private float espRotation;

    public KillAura() {
        addSetting(targetMode);
        addSetting(sorting);
        addSetting(players);
        addSetting(mobs);
        addSetting(invisibles);
        addSetting(range);
        addSetting(blockRaytrace);
        addSetting(shieldBreaker);
        addSetting(minCPS);
        addSetting(maxCPS);
        addSetting(rotationSpeed);
        addSetting(targetESP);
        addSetting(espColor);
    }

    @Override
    protected void onEnable() {
        target = null;
        currentYaw = 0;
        currentPitch = 0;
    }

    @Override
    protected void onDisable() {
        target = null;
    }

    @EventTarget(priority = Event.Priority.HIGH)
    public void onUpdate(EventUpdate event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        target = findTarget();
        if (target == null) return;

        // Рассчитываем целевые углы (Silent Rotation — пакеты отдельно от визуала)
        class_243 eyePos = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23320(), mc.field_1724.method_23321());
        class_243 targetPos = target.method_19538().method_1031(0, target.method_17682() * 0.5, 0);
        double dx = targetPos.field_1352 - eyePos.field_1352;
        double dy = targetPos.field_1351 - eyePos.field_1351;
        double dz = targetPos.field_1350 - eyePos.field_1350;
        double distXZ = Math.sqrt(dx * dx + dz * dz);

        targetYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        targetPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.max(distXZ, 0.0001)));
        targetPitch = MathUtils.clamp(targetPitch, -90.0f, 90.0f);

        // Плавная интерполяция углов (Smooth Rotation)
        float speed = rotationSpeed.floatValue();
        float deltaYaw = MathUtils.wrapDegrees(targetYaw - currentYaw);
        float deltaPitch = targetPitch - currentPitch;
        currentYaw += MathUtils.clamp(deltaYaw, -speed, speed);
        currentPitch += MathUtils.clamp(deltaPitch, -speed * 0.7f, speed * 0.7f);

        // CPS логика с рандомизацией (обход античитов)
        long now = System.currentTimeMillis();
        double cps = MathUtils.random(minCPS.getValue(), maxCPS.getValue());
        long interval = (long) (1000.0 / cps);

        // Ждём пока целевой углов пролетит足够的 близость
        float angleToTarget = (float) Math.sqrt(deltaYaw * deltaYaw + deltaPitch * deltaPitch);
        if (angleToTarget < 15.0f && now - lastAttackTime >= interval) {
            // AutoTool: лучший инструмент
            int bestSlot = findBestWeapon();
            if (bestSlot >= 0 && bestSlot != mc.field_1724.field_7514.field_7545) {
                mc.field_1724.field_7514.field_7545 = bestSlot;
            }

            // ShieldBreaker: топор если цель блокирует щитом
            if (shieldBreaker.isOn() && target.method_6039()) {
                int axeSlot = findAxe();
                if (axeSlot >= 0 && axeSlot != mc.field_1724.field_7514.field_7545) {
                    mc.field_1724.field_7514.field_7545 = axeSlot;
                }
            }

            // Атака через пакеты (Silent — визуально не поворачиваем игрока)
            mc.field_1761.method_2918(mc.field_1724, target);
            mc.field_1724.method_6104(class_1268.field_5808);
            lastAttackTime = now;
        }

        // Switch: смена цели каждые 20 тиков
        if (targetMode.is("Switch")) {
            switchIndex++;
        }
    }

    @EventTarget(priority = Event.Priority.LOW)
    public void onRender3D(EventRender3D event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (!targetESP.isOn()) return;
        if (target == null || target.field_5988) return;

        espRotation += event.getTickDelta() * 2.0f;

        // Анимированное 3D-кольцо вокруг цели
        class_243 pos = target.method_19538();
        float r = espColor.getRf();
        float g = espColor.getGf();
        float b = espColor.getBf();

        // Спираль/кольцо с затуханием
        float radius = (float) (target.method_17681() * 0.75);
        float yOffset = (float) (Math.sin(espRotation) * 0.3);

        RenderUtils.drawCircle(event.getMatrixStack(),
                pos.field_1352, pos.field_1351 + target.method_17682() * 0.5 + yOffset, pos.field_1350,
                radius, r, g, b, 0.8f);

        // Второе кольцо (более тонкое, выше)
        RenderUtils.drawCircle(event.getMatrixStack(),
                pos.field_1352, pos.field_1351 + target.method_17682() * 0.5 + yOffset + 0.1, pos.field_1350,
                radius * 0.8f, r, g, b, 0.4f);
    }

    private class_1309 findTarget() {
        if (mc.field_1724 == null || mc.field_1687 == null) return null;

        class_238 searchBox = mc.field_1724.method_5829().method_1014(range.getValue());
        List<class_1309> candidates = new ArrayList<>();

        for (class_1297 entity : mc.field_1687.method_8390(class_1297.class, searchBox, e -> e instanceof class_1309)) {
            if (!(entity instanceof class_1309)) continue;
            class_1309 living = (class_1309) entity;
            if (living == mc.field_1724) continue;
            if (living.field_5988) continue;
            if (!players.isOn() && living instanceof class_1657) continue;
            if (!mobs.isOn() && living instanceof class_1569) continue;
            if (!invisibles.isOn() && living.method_5767()) continue;
            if (living.method_6032() <= 0) continue;

            double dist = mc.field_1724.method_5858(living);
            if (dist > range.getValue() * range.getValue()) continue;

            candidates.add(living);
        }

        if (candidates.isEmpty()) return null;

        // Сортировка
        if (sorting.is("Health")) {
            candidates.sort(Comparator.comparingDouble(class_1309::method_6032));
        } else {
            candidates.sort(Comparator.comparingDouble(mc.field_1724::method_5858));
        }

        // Switch логика
        if (targetMode.is("Switch") && candidates.size() > 1) {
            return candidates.get(switchIndex % candidates.size());
        }

        return candidates.get(0);
    }

    private int findBestWeapon() {
        if (mc.field_1724 == null) return -1;
        int best = -1;
        float bestDmg = -1;
        for (int i = 0; i < 9; i++) {
            net.minecraft.class_1799 stack = mc.field_1724.field_7514.method_5438(i);
            if (stack.method_7960()) continue;
            float dmg = getAttackDamage(stack);
            if (dmg > bestDmg) {
                bestDmg = dmg;
                best = i;
            }
        }
        return best;
    }

    private int findAxe() {
        if (mc.field_1724 == null) return -1;
        for (int i = 0; i < 9; i++) {
            net.minecraft.class_1799 stack = mc.field_1724.field_7514.method_5438(i);
            if (stack.method_7960()) continue;
            if (stack.method_7909() instanceof net.minecraft.class_1743) return i;
        }
        return -1;
    }

    private float getAttackDamage(net.minecraft.class_1799 stack) {
        net.minecraft.class_1792 item = stack.method_7909();
        if (item instanceof net.minecraft.class_1829) {
            return ((net.minecraft.class_1829) item).method_8020();
        }
        if (item instanceof net.minecraft.class_1831) {
            return ((net.minecraft.class_1831) item).method_8022().method_8028();
        }
        return 1.0f;
    }

    // Геттеры для TargetHUD
    public class_1309 getTarget() {
        return target;
    }

    public float getCurrentYaw() {
        return currentYaw;
    }

    public float getCurrentPitch() {
        return currentPitch;
    }
}
