package ru.kotlovan.mod.module.impl;

import net.minecraft.class_2338;
import net.minecraft.class_243;
import ru.kotlovan.mod.event.Event;
import ru.kotlovan.mod.event.EventUpdate;
import ru.kotlovan.mod.module.EventTarget;
import ru.kotlovan.mod.module.Module;
import ru.kotlovan.mod.module.ModuleInfo;
import ru.kotlovan.mod.setting.ModeSetting;
import ru.kotlovan.mod.setting.NumberSetting;

@ModuleInfo(name = "Jesus", category = "Movement", description = "Хождение по воде")
public class Jesus extends Module {
    private final ModeSetting mode = new ModeSetting("Mode", "Solid", "Solid", "Dolphin", "Trampoline");
    private final NumberSetting trampolineHeight = new NumberSetting("BounceHeight", 0.42, 0.1, 1.0, 0.05);

    private boolean wasTouchingWater;
    private int dolphinTimer;

    public Jesus() {
        addSetting(mode);
        addSetting(trampolineHeight);
    }

    @Override
    protected void onEnable() {
        wasTouchingWater = false;
        dolphinTimer = 0;
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        class_243 vel = mc.field_1724.method_18798();
        class_2338 below = new class_2338(mc.field_1724.method_23317(), mc.field_1724.method_23318() - 0.1, mc.field_1724.method_23321());
        boolean onLiquid = isLiquid(below);

        if (mode.is("Solid")) {
            if (onLiquid && !mc.field_1724.method_7337()) {
                mc.field_1724.method_5814(mc.field_1724.method_23317(), Math.floor(mc.field_1724.method_23318()) + 0.99, mc.field_1724.method_23321());
                mc.field_1724.method_18800(vel.field_1352, 0, vel.field_1350);
                if (mc.field_1724.field_3913.field_3904) {
                    mc.field_1724.method_18800(vel.field_1352, 0.31, vel.field_1350);
                }
            }
        } else if (mode.is("Dolphin")) {
            if (mc.field_1724.method_5799() && mc.field_1724.field_3913.field_3904) {
                dolphinTimer++;
                if (dolphinTimer > 5) {
                    mc.field_1724.method_18800(vel.field_1352, 0.33, vel.field_1350);
                    dolphinTimer = 0;
                }
            } else {
                dolphinTimer = 0;
            }
        } else if (mode.is("Trampoline")) {
            if (onLiquid && mc.field_1724.field_3913.field_3904) {
                mc.field_1724.method_18800(vel.field_1352, trampolineHeight.getValue(), vel.field_1350);
            }
        }

        wasTouchingWater = mc.field_1724.method_5799();
    }

    private boolean isLiquid(class_2338 pos) {
        return mc.field_1687.method_8320(pos).method_26207().method_15797();
    }
}
