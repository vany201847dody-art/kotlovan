package ru.kotlovan.mod;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_746;

public class KotlovanClient {

    private final class_310 mc = class_310.method_1551();

    // ------ Toggles ------
    private boolean nuker;
    private boolean fly;
    private boolean speed;
    private boolean sprint;
    private boolean noFall;
    private boolean killAura;
    private boolean fullBright;
    private boolean step;
    private boolean airJump;
    private boolean spider;
    private boolean autoTool;
    private boolean instantAttack;

    // ------ Values ------
    private int nukerRadius = 5;
    private double speedMul = 2.0;
    private double killAuraRange = 4.5;
    private int oldGamma = -1;

    public void tick() {
        class_746 player = this.mc.field_1724;
        if (player == null || this.mc.field_1687 == null) {
            if (this.fullBright && this.oldGamma >= 0) {
                this.mc.field_1690.field_1840 = this.oldGamma;
                this.oldGamma = -1;
            }
            return;
        }

        this.onKey();
        if (this.sprint) this.applySprint(player);
        if (this.noFall) this.applyNoFall(player);
        if (this.step) player.field_6013 = 1.2f;
        else player.field_6013 = 0.6f;
        if (this.airJump) this.applyAirJump(player);
        if (this.fly) this.applyFly(player);
        if (this.speed) this.applySpeed(player);
        if (this.spider) this.applySpider(player);
        this.applyFullBright(player);
        if (this.nuker) this.doNukerTick(player);
        if (this.killAura) this.doKillAura(player);
    }

    // ---------------- NUKER ----------------
    public void doNukerTick(class_746 player) {
        // Активируемся при зажатии ПКМ (добыча) — очищаем куб вокруг целевого/своего блока
        if (!this.mc.field_1690.field_1904.method_1434()) return;
        class_2338 center = null;
        if (this.mc.field_1765 instanceof net.minecraft.class_3965) {
            center = ((net.minecraft.class_3965) this.mc.field_1765).method_17777();
        }
        if (center == null) {
            center = new class_2338(player.method_19538());
        }
        this.clearArea(center, player);
    }

    private void clearArea(class_2338 center, class_746 player) {
        class_638 world = this.mc.field_1687;
        int r = Math.max(1, Math.min(this.nukerRadius, 8));
        int count = 0;
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    class_2338 pos = center.method_10069(dx, dy, dz);
                    if (pos.equals(new class_2338(player.method_19538()))) continue;
                    class_2680 bs = world.method_8320(pos);
                    class_2248 b = bs.method_26204();
                    if (b.equals(class_2246.field_9987) || b.equals(class_2246.field_10124)
                            || b.equals(class_2246.field_10543) || b.equals(class_2246.field_10243)
                            || b.equals(class_2246.field_10382) || b.equals(class_2246.field_10164)) {
                        continue;
                    }
                    if (this.autoTool) {
                        int slot = bestSlotFor(world, pos, bs);
                        if (slot >= 0) player.field_7514.field_7545 = slot;
                    }
                    world.method_8652(pos, class_2246.field_10124.method_9564(), 3);
                    count++;
                }
            }
        }
        if (count > 0) {
            int size = r * 2 + 1;
            KotlovanMod.chat("Котлован " + size + "x" + size + "x" + size + " очищен (" + count + " блоков)");
        }
    }

    private int bestSlotFor(class_638 world, class_2338 pos, class_2680 state) {
        if (this.mc.field_1724 == null) return -1;
        int best = -1;
        float bestScore = -1;
        for (int i = 0; i < 9; i++) {
            class_1799 stack = this.mc.field_1724.field_7514.method_5438(i);
            if (stack.method_7960()) continue;
            float score = stack.method_7924(state);
            int eff = class_1890.method_8225(class_1893.field_9131, stack);
            score *= 1.0f + eff * 0.3f;
            if (score > bestScore) {
                bestScore = score;
                best = i;
            }
        }
        return best;
    }

    // ---------------- FLY ----------------
    private void applyFly(class_746 player) {
        player.field_7503.field_7479 = true;
        class_243 vel = player.method_18798();
        double sp = 0.4;
        if (this.speed) sp *= this.speedMul;
        boolean fwd = this.mc.field_1690.field_1894.method_1434();
        boolean back = this.mc.field_1690.field_1881.method_1434();
        boolean left = this.mc.field_1690.field_1913.method_1434();
        boolean right = this.mc.field_1690.field_1849.method_1434();
        boolean up = this.mc.field_1690.field_1903.method_1434();
        boolean down = this.mc.field_1690.field_1832.method_1434();

        double yawRad = Math.toRadians(player.method_5705(1.0f));
        double forwardX = -Math.sin(yawRad) * sp;
        double forwardZ = Math.cos(yawRad) * sp;
        double strafeX = Math.cos(yawRad) * sp;
        double strafeZ = Math.sin(yawRad) * sp;

        double mx = 0, my = 0, mz = 0;
        if (fwd) { mx += forwardX; mz += forwardZ; }
        if (back) { mx -= forwardX; mz -= forwardZ; }
        if (right) { mx += strafeX; mz -= strafeZ; }
        if (left) { mx -= strafeX; mz += strafeZ; }
        if (up) my += sp;
        if (down) my -= sp;

        double nx = vel.field_1352 * 0.0 + mx;
        double ny = up || down ? my : (player.method_24828() ? 0.0 : vel.field_1351);
        double nz = vel.field_1350 * 0.0 + mz;
        player.method_18800(nx, ny, nz);
    }

    // ---------------- SPEED ----------------
    private void applySpeed(class_746 player) {
        if (this.fly) return;
        if (!player.method_24828()) return;
        boolean moving = this.mc.field_1690.field_1894.method_1434()
                || this.mc.field_1690.field_1881.method_1434()
                || this.mc.field_1690.field_1913.method_1434()
                || this.mc.field_1690.field_1849.method_1434();
        if (!moving) return;
        class_243 vel = player.method_18798();
        player.method_18800(vel.field_1352 * this.speedMul, vel.field_1351, vel.field_1350 * this.speedMul);
    }

    // ---------------- AUTO SPRINT ----------------
    private void applySprint(class_746 player) {
        boolean moving = this.mc.field_1690.field_1894.method_1434();
        if (moving && !player.method_5715()) {
            player.method_5728(true);
        }
    }

    // ---------------- NO FALL ----------------
    private void applyNoFall(class_746 player) {
        if (!player.method_24828()) {
            player.field_6017 = 0.0f;
        }
    }

    // ---------------- AIR JUMP ----------------
    private void applyAirJump(class_746 player) {
        if (!player.method_24828() && this.mc.field_1690.field_1903.method_1434()) {
            class_243 vel = player.method_18798();
            player.method_18800(vel.field_1352, 0.42, vel.field_1350);
            player.method_6100(false);
        }
    }

    // ---------------- SPIDER / WALL CLIMB ----------------
    private void applySpider(class_746 player) {
        if (player.field_5976 && this.mc.field_1690.field_1894.method_1434()) {
            class_243 vel = player.method_18798();
            player.method_18800(vel.field_1352, 0.25, vel.field_1350);
        }
    }

    // ---------------- FULLBRIGHT ----------------
    private void applyFullBright(class_746 player) {
        if (this.fullBright) {
            this.mc.field_1690.field_1840 = 1000.0;
        } else if (this.mc.field_1690.field_1840 > 1.0) {
            this.mc.field_1690.field_1840 = 0.5;
        }
    }

    // ---------------- KILLAURA (плавная килл-аура) ----------------
    private void doKillAura(class_746 player) {
        if (this.mc.field_1761 == null) return;
        class_238 box = player.method_5829().method_1009(this.killAuraRange, this.killAuraRange, this.killAuraRange);
        List<class_1297> entities = this.mc.field_1687.method_8333(player, box,
                e -> e instanceof class_1309
                        && e != player
                        && e.method_5805()
                        && !(e instanceof class_1657)
                        && (e instanceof class_1569)
        );
        class_1309 target = null;
        double best = Double.MAX_VALUE;
        for (class_1297 e : entities) {
            double d = player.method_5858(e);
            if (d < best) {
                best = d;
                target = (class_1309) e;
            }
        }
        if (target == null) return;

        // Плавный доворот к цели (без рывков)
        smoothAim(player, target);

        // Атакуем только когда прицел уже близко к цели (плавность, без рывков-подскоков)
        if (isAimedAt(player, target, 8.0f)) {
            this.mc.field_1761.method_2918(player, target);
            player.method_6104(class_1268.field_5808);
            if (this.instantAttack) player.method_7350();
        }
    }

    private boolean isAimedAt(class_746 player, class_1309 target, float maxDeg) {
        double dx = target.method_23317() - player.method_23317();
        double dy = (target.method_23318() + target.method_17682() * 0.5) - (player.method_23318() + 1.52);
        double dz = target.method_23321() - player.method_23321();
        double distXZ = Math.sqrt(dx * dx + dz * dz);
        float targetYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.max(distXZ, 0.0001)));
        float dyaw = Math.abs(wrapDegrees(targetYaw - player.field_6031));
        float dpitch = Math.abs(wrapDegrees(targetPitch - player.field_5965));
        return dyaw < maxDeg && dpitch < maxDeg * 1.5f;
    }

    private float wrapDegrees(float deg) {
        return ((deg + 180f) % 360f + 360f) % 360f - 180f;
    }

    private void smoothAim(class_746 player, class_1309 target) {
        double dx = target.method_23317() - player.method_23317();
        double dy = (target.method_23318() + target.method_17682() * 0.5) - (player.method_23318() + 1.52);
        double dz = target.method_23321() - player.method_23321();
        double distXZ = Math.sqrt(dx * dx + dz * dz);

        float targetYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.max(distXZ, 0.0001)));

        // Скорость плавного поворота (градусов за тик)
        float turnSpeed = 6.0f;
        float newYaw = lerpAngle(player.field_6031, targetYaw, turnSpeed);
        float newPitch = lerpFloat(player.field_5965, targetPitch, turnSpeed * 0.7f);

        player.field_6031 = newYaw;
        player.field_5965 = newPitch;
        player.field_6241 = newYaw;
        player.field_6283 = newYaw;
        player.field_5982 = player.field_6031;
        player.field_6004 = player.field_5965;
    }

    private float lerpFloat(float from, float to, float maxStep) {
        float diff = to - from;
        if (diff > maxStep) diff = maxStep;
        if (diff < -maxStep) diff = -maxStep;
        return from + diff;
    }

    private float lerpAngle(float from, float to, float maxStep) {
        float diff = wrapDegrees(to - from);
        if (diff > maxStep) diff = maxStep;
        if (diff < -maxStep) diff = -maxStep;
        return from + diff;
    }

    // ---------------- TOGGLES ----------------
    private void onKey() {
        if (KotlovanMod.NUKER_KEY.method_1436()) this.toggleNuker();
        if (KotlovanMod.FLY_KEY.method_1436()) this.toggleFly();
        if (KotlovanMod.SPEED_KEY.method_1436()) this.toggleSpeed();
        if (KotlovanMod.SPRINT_KEY.method_1436()) this.toggleSprint();
        if (KotlovanMod.NOFALL_KEY.method_1436()) this.toggleNoFall();
        if (KotlovanMod.KILLAURA_KEY.method_1436()) this.toggleKillAura();
        if (KotlovanMod.FULLBRIGHT_KEY.method_1436()) this.toggleFullBright();
        if (KotlovanMod.STEP_KEY.method_1436()) this.toggleStep();
        if (KotlovanMod.AIRJUMP_KEY.method_1436()) this.toggleAirJump();
        if (KotlovanMod.SPIDER_KEY.method_1436()) this.toggleSpider();
        if (KotlovanMod.AUTOTOOL_KEY.method_1436()) this.toggleAutoTool();
        if (KotlovanMod.INSTANT_KEY.method_1436()) this.toggleInstantAttack();
    }

    public void toggleNuker() { this.nuker = !this.nuker; KotlovanMod.chat("Nuker " + this.on(this.nuker)); }
    public void toggleFly() {
        this.fly = !this.fly;
        if (this.mc.field_1724 != null && !this.fly) {
            this.mc.field_1724.field_7503.field_7479 = false;
        }
        KotlovanMod.chat("Fly " + this.on(this.fly));
    }
    public void toggleSpeed() { this.speed = !this.speed; KotlovanMod.chat("Speed x" + this.speedMul + " " + this.on(this.speed)); }
    public void toggleSprint() { this.sprint = !this.sprint; KotlovanMod.chat("AutoSprint " + this.on(this.sprint)); }
    public void toggleNoFall() { this.noFall = !this.noFall; KotlovanMod.chat("NoFall " + this.on(this.noFall)); }
    public void toggleKillAura() { this.killAura = !this.killAura; KotlovanMod.chat("KillAura " + this.on(this.killAura)); }
    public void toggleFullBright() {
        this.fullBright = !this.fullBright;
        if (!this.fullBright && this.mc.field_1690 != null && this.mc.field_1690.field_1840 > 1.0) {
            this.mc.field_1690.field_1840 = 0.5;
        }
        KotlovanMod.chat("FullBright " + this.on(this.fullBright));
    }
    public void toggleStep() { this.step = !this.step; KotlovanMod.chat("Step " + this.on(this.step)); }
    public void toggleAirJump() { this.airJump = !this.airJump; KotlovanMod.chat("AirJump " + this.on(this.airJump)); }
    public void toggleSpider() { this.spider = !this.spider; KotlovanMod.chat("Spider " + this.on(this.spider)); }
    public void toggleAutoTool() { this.autoTool = !this.autoTool; KotlovanMod.chat("AutoTool " + this.on(this.autoTool)); }
    public void toggleInstantAttack() { this.instantAttack = !this.instantAttack; KotlovanMod.chat("InstantAttack " + this.on(this.instantAttack)); }

    private String on(boolean b) {
        return b ? "\u00a7a\u0412\u041a\u041b" : "\u00a7c\u0412\u042b\u041a\u041b";
    }

    // ---------------- GETTERS / SETTERS ----------------
    public boolean isNuker() { return nuker; }
    public boolean isFly() { return fly; }
    public boolean isSpeed() { return speed; }
    public boolean isSprint() { return sprint; }
    public boolean isNoFall() { return noFall; }
    public boolean isKillAura() { return killAura; }
    public boolean isFullBright() { return fullBright; }
    public boolean isStep() { return step; }
    public boolean isAirJump() { return airJump; }
    public boolean isSpider() { return spider; }
    public boolean isAutoTool() { return autoTool; }
    public boolean isInstantAttack() { return instantAttack; }
    public int getNukerRadius() { return nukerRadius; }
    public void setNukerRadius(int r) { this.nukerRadius = r; }
    public double getSpeedMul() { return speedMul; }
    public void setSpeedMul(double m) { this.speedMul = m; }
    public double getKillAuraRange() { return killAuraRange; }
    public void setKillAuraRange(double r) { this.killAuraRange = r; }
}
