package ru.kotlovan.mod;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_746;

public class KotlovanClient {

    private final class_310 mc = class_310.method_1551();

    // ------ Toggles ------
    private boolean nuker;
    private boolean fly;
    private boolean speed;
    private boolean sprint;
    private boolean noFall;
    private boolean killAura;
    private boolean fullBright;
    private boolean step;
    private boolean airJump;
    private boolean spider;
    private boolean autoTool;
    private boolean instantAttack;
    private boolean glide;
    private boolean longJump;
    private boolean criticals;
    private boolean autoSword;
    private boolean freecam;
    private boolean chestStealer;

    // ------ Новые модули ------
    private boolean timer;
    private boolean velocity;
    private boolean noWeb;
    private boolean fastLadder;
    private boolean safeWalk;
    private boolean esp;
    private boolean tracers;
    private boolean xray;
    private boolean noRender;
    private int timerMul = 2;
    private double velocityReduce = 0.8;

    // ------ Режим скрытия HUD (чтобы в записи/на скрине не светились читы) ------
    private boolean hideHud = false;

    // ------ Freecam state ------
    private class_1531 cameraStand;
    private class_243 freecamPlayerPos;
    private float freecamPlayerYaw;
    private float freecamPlayerPitch;
    private boolean wasFlying;

    // ------ Значения ------
    private int nukerRadius = 5;
    private double speedMul = 2.0;
    private double killAuraRange = 4.5;
    private int oldGamma = -1;

    // ------ NameSpoof ------
    private String spoofName = "";

    public void tick() {
        class_746 player = this.mc.field_1724;
        if (player == null || this.mc.field_1687 == null) {
            if (this.fullBright && this.oldGamma >= 0) {
                this.mc.field_1690.field_1840 = this.oldGamma;
                this.oldGamma = -1;
            }
            if (this.freecam) this.disableFreecam();
            return;
        }

        this.onKey();
        if (this.freecam) {
            this.tickFreecam(player);
            return;
        }
        if (this.sprint) this.applySprint(player);
        if (this.noFall) this.applyNoFall(player);
        if (this.step) player.field_6013 = 1.2f;
        else player.field_6013 = 0.6f;
        if (this.airJump) this.applyAirJump(player);
        if (this.fly) this.applyFly(player);
        if (this.speed) this.applySpeed(player);
        if (this.glide) this.applyGlide(player);
        if (this.longJump) this.applyLongJump(player);
        if (this.spider) this.applySpider(player);
        this.applyFullBright(player);
        if (this.nuker) this.doNukerTick(player);
        if (this.chestStealer) this.tryChestSteal();
        if (this.killAura) this.doKillAura(player);
        if (this.velocity) this.applyVelocity(player);
        if (this.noWeb) this.applyNoWeb(player);
        if (this.fastLadder && player.method_6101()) {
            class_243 v = player.method_18798();
            player.method_18800(v.field_1352, 0.22, v.field_1350);
        }
        if (this.safeWalk) {
            player.method_18799(player.method_18798());
        }
    }

    // ================ VELOCITY (анти-отброс) ================
    private void applyVelocity(class_746 player) {
        class_243 v = player.method_18798();
        if (Math.abs(v.field_1351) < 0.3 && v.field_1351 < 0) v = new class_243(v.field_1352, v.field_1351 * (1.0 - this.velocityReduce), v.field_1350);
        player.method_18800(v.field_1352 * (1.0 - this.velocityReduce * 0.5), v.field_1351, v.field_1350 * (1.0 - this.velocityReduce * 0.5));
    }

    // ================ NO WEB (не вязнуть в паутине) ================
    private void applyNoWeb(class_746 player) {
        player.field_6013 = 1.2f;
        class_243 v = player.method_18798();
        player.method_18800(v.field_1352 * 0.98, v.field_1351, v.field_1350 * 0.98);
    }

    // ================ NUKER (реальное ломание блоков пакетами) ================
    private class_2338 nukerCurrent;
    private int nukerIndex;
    private List<class_2338> nukerQueue = new ArrayList<>();
    private int nukerScanTick;

    public void doNukerTick(class_746 player) {
        if (player == null || this.mc.field_1761 == null) return;
        // Активируемся при зажатии ПКМ (добыча)
        boolean active = this.mc.field_1690.field_1904.method_1434();
        if (!active) {
            this.nukerCurrent = null;
            this.nukerQueue.clear();
            if (this.mc.field_1761.method_2923()) {
                this.mc.field_1761.method_2925();
            }
            return;
        }

        class_2338 center = null;
        if (this.mc.field_1765 instanceof net.minecraft.class_3965) {
            center = ((net.minecraft.class_3965) this.mc.field_1765).method_17777();
        }
        if (center == null) {
            center = new class_2338(player.method_19538());
        }

        // Пересобираем очередь блоков вокруг цели каждые 20 тиков (дешево)
        this.nukerScanTick++;
        if (this.nukerQueue.isEmpty() || this.nukerScanTick >= 20) {
            this.nukerQueue.clear();
            int r = Math.max(1, Math.min(this.nukerRadius, 8));
            for (int dx = -r; dx <= r; dx++) {
                for (int dy = -r; dy <= r; dy++) {
                    for (int dz = -r; dz <= r; dz++) {
                        class_2338 pos = center.method_10069(dx, dy, dz);
                        class_2680 bs = this.mc.field_1687.method_8320(pos);
                        class_2248 b = bs.method_26204();
                        if (bs.method_26215() || b.equals(class_2246.field_9987)
                                || b.equals(class_2246.field_10499)
                                || b.equals(class_2246.field_10382) || b.equals(class_2246.field_10164)) {
                            continue;
                        }
                        this.nukerQueue.add(pos);
                    }
                }
            }
            this.nukerScanTick = 0;
            this.nukerIndex = 0;
        }

        if (this.nukerQueue.isEmpty()) return;

        // Берём первый живой блок в очереди
        class_2338 target = null;
        while (this.nukerIndex < this.nukerQueue.size()) {
            class_2338 p = this.nukerQueue.get(this.nukerIndex);
            class_2680 bs = this.mc.field_1687.method_8320(p);
            if (!bs.method_26215() && !bs.method_26204().equals(class_2246.field_9987)) {
                target = p;
                break;
            }
            this.nukerIndex++;
        }
        if (target == null) return;

        // Реальные пакеты ломания: updateBlockBreakingProgress возвращает true, когда блок сломан
        if (this.autoTool) {
            class_2680 bs = this.mc.field_1687.method_8320(target);
            int slot = bestSlotFor(this.mc.field_1687, target, bs);
            if (slot >= 0 && slot != player.field_7514.field_7545) {
                player.field_7514.field_7545 = slot;
            }
        }

        boolean broken = this.mc.field_1761.method_2902(target, class_2350.field_11036);
        this.nukerCurrent = target;
        if (broken) {
            this.nukerIndex++;
        }
    }

    private int bestSlotFor(class_638 world, class_2338 pos, class_2680 state) {
        if (this.mc.field_1724 == null) return -1;
        int best = -1;
        float bestScore = -1;
        for (int i = 0; i < 9; i++) {
            class_1799 stack = this.mc.field_1724.field_7514.method_5438(i);
            if (stack.method_7960()) continue;
            float score = stack.method_7924(state);
            int eff = class_1890.method_8225(class_1893.field_9131, stack);
            score *= 1.0f + eff * 0.3f;
            if (score > bestScore) {
                bestScore = score;
                best = i;
            }
        }
        return best;
    }

    // ================ CHEST STEALER ================
    private int chestStealCooldown = 0;

    private void tryChestSteal() {
        if (this.mc.field_1724 == null || this.mc.field_1761 == null) return;
        if (chestStealCooldown > 0) { chestStealCooldown--; return; }
        net.minecraft.class_1703 handler = this.mc.field_1724.field_7512;
        if (handler == null) return;
        // Определяем, открыт ли контейнер (не обычный игровой экран без контейнера)
        int containerSlots = handler.field_7761.size() - 36;
        if (containerSlots <= 0) return;

        boolean moved = false;
        for (int i = 0; i < containerSlots; i++) {
            try {
                class_1799 stack = handler.method_7611(i).method_7677();
                if (!stack.method_7960()) {
                    this.mc.field_1761.method_2906(handler.field_7763, i, 0, class_1713.field_7794, this.mc.field_1724);
                    moved = true;
                    chestStealCooldown = 3;
                    break;
                }
            } catch (Exception ignored) {
            }
        }
        if (moved) {
            KotlovanMod.chat("§aChestStealer: забираю предметы...");
        }
    }

    // ================ FLY ================
    private void applyFly(class_746 player) {
        player.field_7503.field_7479 = true;
        class_243 vel = player.method_18798();
        double sp = 0.4;
        if (this.speed) sp *= this.speedMul;
        if (this.timer) sp *= this.timerMul;
        boolean fwd = this.mc.field_1690.field_1894.method_1434();
        boolean back = this.mc.field_1690.field_1881.method_1434();
        boolean left = this.mc.field_1690.field_1913.method_1434();
        boolean right = this.mc.field_1690.field_1849.method_1434();
        boolean up = this.mc.field_1690.field_1903.method_1434();
        boolean down = this.mc.field_1690.field_1832.method_1434();

        double yawRad = Math.toRadians(player.method_5705(1.0f));
        double forwardX = -Math.sin(yawRad) * sp;
        double forwardZ = Math.cos(yawRad) * sp;
        double strafeX = Math.cos(yawRad) * sp;
        double strafeZ = Math.sin(yawRad) * sp;

        double mx = 0, my = 0, mz = 0;
        if (fwd) { mx += forwardX; mz += forwardZ; }
        if (back) { mx -= forwardX; mz -= forwardZ; }
        if (right) { mx += strafeX; mz -= strafeZ; }
        if (left) { mx -= strafeX; mz += strafeZ; }
        if (up) my += sp;
        if (down) my -= sp;

        double nx = mx;
        double ny = up || down ? my : (player.method_24828() ? 0.0 : vel.field_1351);
        double nz = mz;
        player.method_18800(nx, ny, nz);
    }

    // ================ SPEED ================
    private void applySpeed(class_746 player) {
        if (this.fly) return;
        if (!player.method_24828()) return;
        boolean moving = this.mc.field_1690.field_1894.method_1434()
                || this.mc.field_1690.field_1881.method_1434()
                || this.mc.field_1690.field_1913.method_1434()
                || this.mc.field_1690.field_1849.method_1434();
        if (!moving) return;
        class_243 vel = player.method_18798();
        double tm = this.timer ? this.timerMul : 1.0;
        player.method_18800(vel.field_1352 * this.speedMul * tm, vel.field_1351, vel.field_1350 * this.speedMul * tm);
    }

    // ================ GLIDE (плавное замедленное падение) ================
    private void applyGlide(class_746 player) {
        if (player.method_24828() || this.mc.field_1690.field_1903.method_1434()) return;
        class_243 vel = player.method_18798();
        if (vel.field_1351 < 0) {
            player.method_18800(vel.field_1352, vel.field_1351 * 0.55, vel.field_1350);
        }
    }

    // ================ LONG JUMP (дальний прыжок) ================
    private void applyLongJump(class_746 player) {
        boolean moving = this.mc.field_1690.field_1894.method_1434();
        if (!moving || !this.mc.field_1690.field_1903.method_1434()) return;
        if (!player.method_24828()) return;
        double yawRad = Math.toRadians(player.method_5705(1.0f));
        double boost = 2.6 * (this.speed ? this.speedMul : 1.0);
        double vx = -Math.sin(yawRad) * boost;
        double vz = Math.cos(yawRad) * boost;
        player.method_18800(vx, 0.5, vz);
    }

    // ================ AUTO SPRINT ================
    private void applySprint(class_746 player) {
        boolean moving = this.mc.field_1690.field_1894.method_1434();
        if (moving && !player.method_5715()) {
            player.method_5728(true);
        }
    }

    // ================ NO FALL ================
    private void applyNoFall(class_746 player) {
        if (!player.method_24828()) {
            player.field_6017 = 0.0f;
        }
    }

    // ================ AIR JUMP ================
    private void applyAirJump(class_746 player) {
        if (!player.method_24828() && this.mc.field_1690.field_1903.method_1434()) {
            class_243 vel = player.method_18798();
            player.method_18800(vel.field_1352, 0.42, vel.field_1350);
            player.method_6100(false);
        }
    }

    // ================ SPIDER / WALL CLIMB ================
    private void applySpider(class_746 player) {
        if (player.field_5976 && this.mc.field_1690.field_1894.method_1434()) {
            class_243 vel = player.method_18798();
            player.method_18800(vel.field_1352, 0.25, vel.field_1350);
        }
    }

    // ================ FULLBRIGHT ================
    private void applyFullBright(class_746 player) {
        if (this.fullBright) {
            this.mc.field_1690.field_1840 = 1000.0;
        } else if (this.mc.field_1690.field_1840 > 1.0) {
            this.mc.field_1690.field_1840 = 0.5;
        }
    }

    // ================ KILLAURA (плавная, +Criticals +AutoSword) ================
    private void doKillAura(class_746 player) {
        if (this.mc.field_1761 == null) return;
        class_238 box = player.method_5829().method_1009(this.killAuraRange, this.killAuraRange, this.killAuraRange);
        List<class_1297> entities = this.mc.field_1687.method_8333(player, box,
                e -> e instanceof class_1309
                        && e != player
                        && e.method_5805()
                        && !(e instanceof class_1657)
                        && (e instanceof class_1569)
        );
        class_1309 target = null;
        double best = Double.MAX_VALUE;
        for (class_1297 e : entities) {
            double d = player.method_5858(e);
            if (d < best) {
                best = d;
                target = (class_1309) e;
            }
        }
        if (target == null) return;

        // AutoSword: выбираем лучший меч-инструмент в хотбаре
        if (this.autoSword) {
            int slot = bestMeleeSlot();
            if (slot >= 0 && slot != player.field_7514.field_7545) {
                player.field_7514.field_7545 = slot;
            }
        }

        // Плавный доворот к цели (без рывков)
        smoothAim(player, target);

        // Criticals: прыжок перед ударом для крит-урона
        if (this.criticals && player.method_24828()) {
            class_243 v = player.method_18798();
            player.method_18800(v.field_1352, 0.42, v.field_1350);
            player.method_24830(false);
        }

        // Атакуем только когда прицел уже близко к цели
        if (isAimedAt(player, target, 8.0f)) {
            this.mc.field_1761.method_2918(player, target);
            player.method_6104(class_1268.field_5808);
            if (this.instantAttack) player.method_7350();
        }
    }

    private int bestMeleeSlot() {
        if (this.mc.field_1724 == null) return -1;
        int best = -1;
        float bestScore = -1;
        for (int i = 0; i < 9; i++) {
            class_1799 stack = this.mc.field_1724.field_7514.method_5438(i);
            if (stack.method_7960()) continue;
            float dmg = getItemDamage(stack);
            if (dmg > bestScore) {
                bestScore = dmg;
                best = i;
            }
        }
        return best;
    }

    private float getItemDamage(class_1799 stack) {
        if (stack.method_7909() instanceof net.minecraft.class_1829) {
            return ((net.minecraft.class_1829) stack.method_7909()).method_8020() + 1.0f;
        }
        if (stack.method_7909() instanceof net.minecraft.class_1743) {
            return ((net.minecraft.class_1743) stack.method_7909()).method_26366();
        }
        return 1.0f;
    }

    private boolean isAimedAt(class_746 player, class_1309 target, float maxDeg) {
        double dx = target.method_23317() - player.method_23317();
        double dy = (target.method_23318() + target.method_17682() * 0.5) - (player.method_23318() + 1.52);
        double dz = target.method_23321() - player.method_23321();
        double distXZ = Math.sqrt(dx * dx + dz * dz);
        float targetYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.max(distXZ, 0.0001)));
        float dyaw = Math.abs(wrapDegrees(targetYaw - player.field_6031));
        float dpitch = Math.abs(wrapDegrees(targetPitch - player.field_5965));
        return dyaw < maxDeg && dpitch < maxDeg * 1.5f;
    }

    private float wrapDegrees(float deg) {
        return ((deg + 180f) % 360f + 360f) % 360f - 180f;
    }

    private void smoothAim(class_746 player, class_1309 target) {
        double dx = target.method_23317() - player.method_23317();
        double dy = (target.method_23318() + target.method_17682() * 0.5) - (player.method_23318() + 1.52);
        double dz = target.method_23321() - player.method_23321();
        double distXZ = Math.sqrt(dx * dx + dz * dz);

        float targetYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.max(distXZ, 0.0001)));

        float turnSpeed = 6.0f;
        float newYaw = lerpAngle(player.field_6031, targetYaw, turnSpeed);
        float newPitch = lerpFloat(player.field_5965, targetPitch, turnSpeed * 0.7f);

        player.field_6031 = newYaw;
        player.field_5965 = newPitch;
        player.field_6241 = newYaw;
        player.field_6283 = newYaw;
        player.field_5982 = player.field_6031;
        player.field_6004 = player.field_5965;
    }

    private float lerpFloat(float from, float to, float maxStep) {
        float diff = to - from;
        if (diff > maxStep) diff = maxStep;
        if (diff < -maxStep) diff = -maxStep;
        return from + diff;
    }

    private float lerpAngle(float from, float to, float maxStep) {
        float diff = wrapDegrees(to - from);
        if (diff > maxStep) diff = maxStep;
        if (diff < -maxStep) diff = -maxStep;
        return from + diff;
    }

    // ================ FREE CAM (камера отлетает от тела, «чтобы не палили») ================
    private void tickFreecam(class_746 player) {
        if (this.cameraStand == null) {
            this.enableFreecam(player);
            return;
        }
        // Тело игрока замирает на месте (не двигаем физически), но смотрит мышью
        if (this.freecamPlayerPos != null) {
            player.method_5814(this.freecamPlayerPos.field_1352, this.freecamPlayerPos.field_1351, this.freecamPlayerPos.field_1350);
        }
        player.method_18800(0, 0, 0);
        player.field_7503.field_7479 = true;
        player.field_5960 = true;

        // Ключевой фикс: мышь уже обновила player.yaw/pitch НА ЭТОТ кадр,
        // а камера смотрит из cameraStand (cameraEntity). Копируем поворот
        // на stand, иначе камеру нельзя крутить мышью (была заморожена).
        this.cameraStand.field_6031 = player.field_6031;
        this.cameraStand.field_5965 = player.field_5965;
        this.cameraStand.field_6241 = player.field_6031;
        this.cameraStand.field_6283 = player.field_6031;
        this.cameraStand.field_5982 = player.field_6031;
        this.cameraStand.field_6004 = player.field_5965;

        double sp = 0.6;
        boolean fwd = this.mc.field_1690.field_1894.method_1434();
        boolean back = this.mc.field_1690.field_1881.method_1434();
        boolean left = this.mc.field_1690.field_1913.method_1434();
        boolean right = this.mc.field_1690.field_1849.method_1434();
        boolean up = this.mc.field_1690.field_1903.method_1434();
        boolean down = this.mc.field_1690.field_1832.method_1434();
        // Движение по направлению взгляда КАМЕРЫ (player.yaw == взгляд)
        double yawRad = Math.toRadians(player.field_6031);

        double mx = 0, my = 0, mz = 0;
        if (fwd) { mx += -Math.sin(yawRad) * sp; mz += Math.cos(yawRad) * sp; }
        if (back) { mx -= -Math.sin(yawRad) * sp; mz -= Math.cos(yawRad) * sp; }
        if (right) { mx += Math.cos(yawRad) * sp; mz -= Math.sin(yawRad) * sp; }
        if (left) { mx -= Math.cos(yawRad) * sp; mz += Math.sin(yawRad) * sp; }
        if (up) my += sp;
        if (down) my -= sp;

        class_243 cp = this.cameraStand.method_19538();
        this.cameraStand.method_5814(cp.field_1352 + mx, cp.field_1351 + my, cp.field_1350 + mz);
        this.cameraStand.method_5808(cp.field_1352 + mx, cp.field_1351 + my, cp.field_1350 + mz, this.cameraStand.field_6031, this.cameraStand.field_5965);
    }

    private void enableFreecam(class_746 player) {
        try {
            this.wasFlying = player.field_7503.field_7479;
            this.freecamPlayerPos = player.method_19538();
            this.freecamPlayerYaw = player.field_6031;
            this.freecamPlayerPitch = player.field_5965;

            class_243 p = player.method_19538();
            this.cameraStand = new class_1531(this.mc.field_1687, p.field_1352, p.field_1351 + 1.6, p.field_1350);
            this.cameraStand.method_5875(true);
            this.cameraStand.method_5648(true);
            this.cameraStand.method_5803(true);
            this.cameraStand.method_5684(true);
            this.cameraStand.field_6031 = player.field_6031;
            this.cameraStand.field_5965 = player.field_5965;
            this.cameraStand.field_6241 = player.field_6031;
            this.cameraStand.field_6283 = player.field_6031;
            this.cameraStand.method_5808(p.field_1352, p.field_1351 + 1.6, p.field_1350, player.field_6031, player.field_5965);

            this.mc.field_1719 = this.cameraStand;
            player.field_7503.field_7479 = true;
            player.field_5960 = true;
            KotlovanMod.chat("§aFreecam §aВКЛ");
        } catch (Exception e) {
            KotlovanMod.chat("§cFreecam: ошибка запуска");
        }
    }

    private void disableFreecam() {
        try {
            this.mc.field_1719 = this.mc.field_1724;
            if (this.cameraStand != null) {
                this.cameraStand.method_5650();
                this.cameraStand = null;
            }
            if (this.mc.field_1724 != null) {
                if (!this.wasFlying) this.mc.field_1724.field_7503.field_7479 = false;
                this.mc.field_1724.field_5960 = false;
            }
            this.freecamPlayerPos = null;
            this.freecam = false;
            KotlovanMod.chat("§cFreecam §cВЫКЛ");
        } catch (Exception ignored) {
        }
    }

    // ================ TOGGLES ================
    private void onKey() {
        if (KotlovanMod.NUKER_KEY.method_1436()) this.toggleNuker();
        if (KotlovanMod.FLY_KEY.method_1436()) this.toggleFly();
        if (KotlovanMod.SPEED_KEY.method_1436()) this.toggleSpeed();
        if (KotlovanMod.SPRINT_KEY.method_1436()) this.toggleSprint();
        if (KotlovanMod.NOFALL_KEY.method_1436()) this.toggleNoFall();
        if (KotlovanMod.KILLAURA_KEY.method_1436()) this.toggleKillAura();
        if (KotlovanMod.FULLBRIGHT_KEY.method_1436()) this.toggleFullBright();
        if (KotlovanMod.STEP_KEY.method_1436()) this.toggleStep();
        if (KotlovanMod.AIRJUMP_KEY.method_1436()) this.toggleAirJump();
        if (KotlovanMod.SPIDER_KEY.method_1436()) this.toggleSpider();
        if (KotlovanMod.AUTOTOOL_KEY.method_1436()) this.toggleAutoTool();
        if (KotlovanMod.INSTANT_KEY.method_1436()) this.toggleInstantAttack();
        if (KotlovanMod.GLIDE_KEY.method_1436()) this.toggleGlide();
        if (KotlovanMod.LONGJUMP_KEY.method_1436()) this.toggleLongJump();
        if (KotlovanMod.CRITICALS_KEY.method_1436()) this.toggleCriticals();
        if (KotlovanMod.AUTOSWORD_KEY.method_1436()) this.toggleAutoSword();
        if (KotlovanMod.FREECAM_KEY.method_1436()) this.toggleFreecam();
        if (KotlovanMod.CHESTSTEAL_KEY.method_1436()) this.toggleChestStealer();
        if (KotlovanMod.HIDEHUD_KEY.method_1436()) this.toggleHideHud();
        if (KotlovanMod.PANIC_KEY.method_1436()) this.panic();
    }

    public void toggleNuker() { this.nuker = !this.nuker; KotlovanMod.chat("Nuker " + this.on(this.nuker)); }
    public void toggleFly() {
        this.fly = !this.fly;
        if (this.mc.field_1724 != null && !this.fly) {
            this.mc.field_1724.field_7503.field_7479 = false;
        }
        KotlovanMod.chat("Fly " + this.on(this.fly));
    }
    public void toggleSpeed() { this.speed = !this.speed; KotlovanMod.chat("Speed x" + this.speedMul + " " + this.on(this.speed)); }
    public void toggleSprint() { this.sprint = !this.sprint; KotlovanMod.chat("AutoSprint " + this.on(this.sprint)); }
    public void toggleNoFall() { this.noFall = !this.noFall; KotlovanMod.chat("NoFall " + this.on(this.noFall)); }
    public void toggleKillAura() { this.killAura = !this.killAura; KotlovanMod.chat("KillAura " + this.on(this.killAura)); }
    public void toggleFullBright() {
        this.fullBright = !this.fullBright;
        if (!this.fullBright && this.mc.field_1690 != null && this.mc.field_1690.field_1840 > 1.0) {
            this.mc.field_1690.field_1840 = 0.5;
        }
        KotlovanMod.chat("FullBright " + this.on(this.fullBright));
    }
    public void toggleStep() { this.step = !this.step; KotlovanMod.chat("Step " + this.on(this.step)); }
    public void toggleAirJump() { this.airJump = !this.airJump; KotlovanMod.chat("AirJump " + this.on(this.airJump)); }
    public void toggleSpider() { this.spider = !this.spider; KotlovanMod.chat("Spider " + this.on(this.spider)); }
    public void toggleAutoTool() { this.autoTool = !this.autoTool; KotlovanMod.chat("AutoTool " + this.on(this.autoTool)); }
    public void toggleInstantAttack() { this.instantAttack = !this.instantAttack; KotlovanMod.chat("InstantAttack " + this.on(this.instantAttack)); }
    public void toggleGlide() { this.glide = !this.glide; KotlovanMod.chat("Glide " + this.on(this.glide)); }
    public void toggleLongJump() { this.longJump = !this.longJump; KotlovanMod.chat("LongJump " + this.on(this.longJump)); }
    public void toggleCriticals() { this.criticals = !this.criticals; KotlovanMod.chat("Criticals " + this.on(this.criticals)); }
    public void toggleAutoSword() { this.autoSword = !this.autoSword; KotlovanMod.chat("AutoSword " + this.on(this.autoSword)); }
    public void toggleChestStealer() { this.chestStealer = !this.chestStealer; KotlovanMod.chat("ChestStealer " + this.on(this.chestStealer)); }
    public void toggleFreecam() {
        if (this.freecam) {
            this.disableFreecam();
        } else {
            this.enableFreecam(this.mc.field_1724);
        }
    }
    public void toggleHideHud() { this.hideHud = !this.hideHud; KotlovanMod.chat("Скрыть HUD-модули " + this.on(this.hideHud)); }
    public void toggleTimer() { this.timer = !this.timer; KotlovanMod.chat("Timer x" + this.timerMul + " " + this.on(this.timer)); }
    public void toggleVelocity() { this.velocity = !this.velocity; KotlovanMod.chat("Velocity " + this.on(this.velocity)); }
    public void toggleNoWeb() { this.noWeb = !this.noWeb; KotlovanMod.chat("NoWeb " + this.on(this.noWeb)); }
    public void toggleFastLadder() { this.fastLadder = !this.fastLadder; KotlovanMod.chat("FastLadder " + this.on(this.fastLadder)); }
    public void toggleSafeWalk() { this.safeWalk = !this.safeWalk; KotlovanMod.chat("SafeWalk " + this.on(this.safeWalk)); }
    public void toggleEsp() { this.esp = !this.esp; KotlovanMod.chat("ESP " + this.on(this.esp)); }
    public void toggleTracers() { this.tracers = !this.tracers; KotlovanMod.chat("Tracers " + this.on(this.tracers)); }
    public void toggleXray() { this.xray = !this.xray; KotlovanMod.chat("X-Ray " + this.on(this.xray)); }
    public void toggleNoRender() { this.noRender = !this.noRender; KotlovanMod.chat("NoRender " + this.on(this.noRender)); }

    public boolean isHideHud() { return this.hideHud; }

    // ================ ПАНИКА (ТРЕВОГА): выключить всё и спрятать GUI ================
    public void panic() {
        this.nuker = false;
        this.fly = false;
        this.speed = false;
        this.sprint = false;
        this.noFall = false;
        this.killAura = false;
        this.fullBright = false;
        this.step = false;
        this.airJump = false;
        this.spider = false;
        this.autoTool = false;
        this.instantAttack = false;
        this.glide = false;
        this.longJump = false;
        this.criticals = false;
        this.autoSword = false;
        this.chestStealer = false;
        this.timer = false;
        this.velocity = false;
        this.noWeb = false;
        this.fastLadder = false;
        this.safeWalk = false;
        this.esp = false;
        this.tracers = false;
        this.xray = false;
        this.noRender = false;

        if (this.freecam) this.disableFreecam();

        if (this.mc.field_1724 != null) {
            this.mc.field_1724.field_7503.field_7479 = false;
            this.mc.field_1724.field_5960 = false;
            this.mc.field_1724.field_6013 = 0.6f;
            if (this.mc.field_1690 != null && this.mc.field_1690.field_1840 > 1.0) {
                this.mc.field_1690.field_1840 = 0.5;
            }
        }
        // Скрыть GUI, если чит-меню открыто
        if (this.mc.field_1755 instanceof ClickGuiScreen) {
            this.mc.method_1507(null);
        }
        KotlovanMod.chat("§c⚠ ТРЕВОГА — все читы выключены!");
    }

    // ================ NameSpoof ================
    public void setName(String name) {
        this.spoofName = name;
    }
    public String getName() {
        return this.spoofName;
    }

    // ================ КОНФИГ ================
    public void updateConfig() {
        KotlovanConfig.save(this);
    }
    public void loadConfig() {
        KotlovanConfig.load(this);
    }

    public void enableConfigLoaded() {}

    private String on(boolean b) {
        return b ? "\u00a7a\u0412\u041a\u041b" : "\u00a7c\u0412\u042b\u041a\u041b";
    }

    // ---------------- SETTERS для загрузки конфига ----------------
    public void setFlyOn(boolean v){ this.fly=v; }
    public void setSpeedOn(boolean v){ this.speed=v; }
    public void setNukerOn(boolean v){ this.nuker=v; }
    public void setKillAuraOn(boolean v){ this.killAura=v; }
    public void setSprintOn(boolean v){ this.sprint=v; }
    public void setNoFallOn(boolean v){ this.noFall=v; }
    public void setFullBrightOn(boolean v){ this.fullBright=v; }
    public void setStepOn(boolean v){ this.step=v; }
    public void setAirJumpOn(boolean v){ this.airJump=v; }
    public void setSpiderOn(boolean v){ this.spider=v; }
    public void setAutoToolOn(boolean v){ this.autoTool=v; }
    public void setInstantAttackOn(boolean v){ this.instantAttack=v; }
    public void setGlideOn(boolean v){ this.glide=v; }
    public void setLongJumpOn(boolean v){ this.longJump=v; }
    public void setCriticalsOn(boolean v){ this.criticals=v; }
    public void setAutoSwordOn(boolean v){ this.autoSword=v; }
    public void setChestStealerOn(boolean v){ this.chestStealer=v; }
    public void setHideHudOn(boolean v){ this.hideHud=v; }
    public void setTimerOn(boolean v){ this.timer=v; }
    public void setVelocityOn(boolean v){ this.velocity=v; }
    public void setNoWebOn(boolean v){ this.noWeb=v; }
    public void setFastLadderOn(boolean v){ this.fastLadder=v; }
    public void setSafeWalkOn(boolean v){ this.safeWalk=v; }
    public void setEspOn(boolean v){ this.esp=v; }
    public void setTracersOn(boolean v){ this.tracers=v; }
    public void setXrayOn(boolean v){ this.xray=v; }
    public void setNoRenderOn(boolean v){ this.noRender=v; }

    // ---------------- GETTERS ----------------
    public boolean isNuker() { return nuker; }
    public boolean isFly() { return fly; }
    public boolean isSpeed() { return speed; }
    public boolean isSprint() { return sprint; }
    public boolean isNoFall() { return noFall; }
    public boolean isKillAura() { return killAura; }
    public boolean isFullBright() { return fullBright; }
    public boolean isStep() { return step; }
    public boolean isAirJump() { return airJump; }
    public boolean isSpider() { return spider; }
    public boolean isAutoTool() { return autoTool; }
    public boolean isInstantAttack() { return instantAttack; }
    public boolean isGlide() { return glide; }
    public boolean isLongJump() { return longJump; }
    public boolean isCriticals() { return criticals; }
    public boolean isAutoSword() { return autoSword; }
    public boolean isFreecam() { return freecam; }
    public boolean isChestStealer() { return chestStealer; }
    public boolean isTimer() { return timer; }
    public boolean isVelocity() { return velocity; }
    public boolean isNoWeb() { return noWeb; }
    public boolean isFastLadder() { return fastLadder; }
    public boolean isSafeWalk() { return safeWalk; }
    public boolean isEsp() { return esp; }
    public boolean isTracers() { return tracers; }
    public boolean isXray() { return xray; }
    public boolean isNoRender() { return noRender; }
    public int getTimerMul() { return timerMul; }
    public void setTimerMul(int m) { this.timerMul = Math.max(1, Math.min(10, m)); }
    public double getVelocityReduce() { return velocityReduce; }
    public void setVelocityReduce(double v) { this.velocityReduce = v; }
    public int getNukerRadius() { return nukerRadius; }
    public void setNukerRadius(int r) { this.nukerRadius = r; }
    public double getSpeedMul() { return speedMul; }
    public void setSpeedMul(double m) { this.speedMul = m; }
    public double getKillAuraRange() { return killAuraRange; }
    public void setKillAuraRange(double r) { this.killAuraRange = r; }
}
