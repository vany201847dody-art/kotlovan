package ru.kotlovan.mod;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_310;
import ru.kotlovan.mod.event.EventBus;
import ru.kotlovan.mod.event.EventRender2D;
import ru.kotlovan.mod.event.EventRender3D;
import ru.kotlovan.mod.event.EventUpdate;
import ru.kotlovan.mod.module.Module;
import ru.kotlovan.mod.module.ModuleManager;

public class Kotlovan {
    private static Kotlovan INSTANCE;
    private boolean initialized;

    public static Kotlovan getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new Kotlovan();
        }
        return INSTANCE;
    }

    public void init() {
        if (initialized) return;

        ModuleManager.getInstance().init();

        // Регистрируем все модули в EventBus
        for (Module module : ModuleManager.getInstance().getModules()) {
            EventBus.getInstance().register(module);
        }

        // Тик-ивенты
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);

        initialized = true;
    }

    private void onTick(class_310 mc) {
        if (mc.field_1724 == null) return;
        EventBus.getInstance().post(new EventUpdate(mc.method_1488()));
    }

    public void onRender3D(net.minecraft.class_4587 matrices, float tickDelta, long nanoTime, net.minecraft.class_1159 projectionMatrix) {
        if (!initialized) return;
        EventBus.getInstance().post(new EventRender3D(matrices, tickDelta, nanoTime, projectionMatrix));
    }

    public void onRender2D(float tickDelta, net.minecraft.class_437 screen) {
        if (!initialized) return;
        EventBus.getInstance().post(new EventRender2D(tickDelta, screen));
    }
}
