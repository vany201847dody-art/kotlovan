package ru.kotlovan.mod.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.kotlovan.mod.KotlovanMod;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import net.minecraft.class_1920;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_776;

@Mixin(class_776.class)
public class BlockRenderManagerMixin {

    // Руды и полезные блоки, которые видно в X-Ray
    private static final Set<class_2248> XRAY_BLOCKS = new HashSet<>();
    static {
        XRAY_BLOCKS.add(class_2246.field_10442);
        XRAY_BLOCKS.add(class_2246.field_10013);
        XRAY_BLOCKS.add(class_2246.field_10571);
        XRAY_BLOCKS.add(class_2246.field_10212);
        XRAY_BLOCKS.add(class_2246.field_10418);
        XRAY_BLOCKS.add(class_2246.field_10080);
        XRAY_BLOCKS.add(class_2246.field_10090);
        XRAY_BLOCKS.add(class_2246.field_10213);
        XRAY_BLOCKS.add(class_2246.field_23077);
        XRAY_BLOCKS.add(class_2246.field_9987);
        XRAY_BLOCKS.add(class_2246.field_9989);
        XRAY_BLOCKS.add(class_2246.field_10540);
        XRAY_BLOCKS.add(class_2246.field_10260);
        XRAY_BLOCKS.add(class_2246.field_10398);
    }

    @Inject(method = "renderBlock", at = @At("HEAD"), cancellable = true)
    private void kotlovan$xray(class_2680 state, class_2338 pos, class_1920 world,
                              class_4587 matrix, class_4588 vertexConsumer,
                              boolean cull, Random random, CallbackInfoReturnable<Boolean> cir) {
        try {
            if (KotlovanMod.client().isXray() && !XRAY_BLOCKS.contains(state.method_26204())) {
                // Не рендерим обычные блоки — просвечивают только руды/бэдрок
                cir.setReturnValue(false);
            }
        } catch (Throwable ignored) {
        }
    }
}
