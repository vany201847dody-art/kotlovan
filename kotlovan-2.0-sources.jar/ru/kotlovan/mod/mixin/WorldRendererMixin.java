package ru.kotlovan.mod.mixin;

import net.minecraft.class_1159;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1921;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4599;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.kotlovan.mod.KotlovanClient;
import ru.kotlovan.mod.KotlovanMod;

@Mixin(class_761.class)
public abstract class WorldRendererMixin {

    @Shadow @Final private class_4599 bufferBuilders;

    @Inject(method = "render", at = @At("RETURN"))
    private void kotlovan$espTracers(class_4587 matrices, float tickDelta, long limitTime,
                                     boolean renderBlockOutline, class_4184 camera,
                                     class_757 gameRenderer, class_765 lightmap,
                                     class_1159 matrix4f, CallbackInfo ci) {
        try {
            KotlovanClient k = KotlovanMod.client();
            if (!k.isEsp() && !k.isTracers()) return;
            class_310 mc = class_310.method_1551();
            if (mc.field_1687 == null || mc.field_1724 == null) return;

            class_243 camPos = camera.method_19326();
            class_4597.class_4598 vcp = this.bufferBuilders.method_23000();

            // Большая область вокруг камеры (64 блока) для ESP/Tracers
            class_238 area = new class_238(camPos.field_1352 - 64, camPos.field_1351 - 32, camPos.field_1350 - 64,
                    camPos.field_1352 + 64, camPos.field_1351 + 64, camPos.field_1350 + 64);
            java.util.List<class_1297> list = mc.field_1687.method_8390(class_1297.class, area,
                    e -> e instanceof class_1309);
            if (list == null) return;

            matrices.method_22903();
            matrices.method_22904(-camPos.field_1352, -camPos.field_1351, -camPos.field_1350);

            for (class_1297 e : list) {
                if (!(e instanceof class_1309) || e == mc.field_1724) continue;
                if (e.field_5988) continue;

                // ESP: цветной бокс вокруг моба
                if (k.isEsp()) {
                    class_238 box = e.method_5829();
                    class_4588 vc = vcp.getBuffer(class_1921.method_23594());
                    class_761.method_22982(matrices, vc, box, 1.0f, 0.2f, 0.2f, 0.8f);
                }

                // Tracers: линия от камеры к мобу
                if (k.isTracers()) {
                    class_243 target = e.method_5836(tickDelta);
                    class_4588 vc = vcp.getBuffer(class_1921.method_23594());
                    float dx = (float) (target.field_1352 - camPos.field_1352);
                    float dy = (float) (target.field_1351 - camPos.field_1351);
                    float dz = (float) (target.field_1350 - camPos.field_1350);
                    vc.method_22918(matrices.method_23760().method_23761(), 0.0f, 0.0f, 0.0f).method_22915(0.2f, 1.0f, 0.2f, 1.0f).method_1344();
                    vc.method_22918(matrices.method_23760().method_23761(), dx, dy, dz).method_22915(0.2f, 1.0f, 0.2f, 1.0f).method_1344();
                }
            }

            if (k.isEsp() || k.isTracers()) {
                vcp.method_22994(class_1921.method_23594());
            }
            matrices.method_22909();
        } catch (Throwable ignored) {
        }
    }
}
