package ru.kotlovan.mod.mixin;

import net.minecraft.class_329;
import net.minecraft.class_4587;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.kotlovan.mod.Kotlovan;

@Mixin(class_329.class)
public class InGameHudMixin {

    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(class_4587 matrices, float tickDelta, CallbackInfo ci) {
        Kotlovan.getInstance().onRender2D(tickDelta, null);
    }
}
