package ru.kotlovan.mod.mixin;

import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_702;
import net.minecraft.class_765;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.kotlovan.mod.KotlovanMod;

@Mixin(class_702.class)
public class ParticleManagerMixin {

    @Inject(method = "renderParticles", at = @At("HEAD"), cancellable = true)
    private void kotlovan$noRenderParticles(class_4587 matrices, class_4597.class_4598 immediate,
                                            class_765 lightmap, class_4184 camera, float tickDelta,
                                            CallbackInfo ci) {
        try {
            if (KotlovanMod.client().isNoRender()) {
                ci.cancel();
            }
        } catch (Throwable ignored) {
        }
    }
}
