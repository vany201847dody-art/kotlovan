package ru.kotlovan.mod;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import net.minecraft.class_2585;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;

public class ClickGuiScreen extends class_437 {

    private static final String[] CATS = {"Движение", "Комбат", "Игрок", "Система"};

    private final KotlovanClient k = KotlovanMod.client();
    private int panelX;
    private int panelY;
    private int selectedCat = 0;

    private List<Module> modules;
    private class_342 nameField;
    private class_342 fieldRadius;
    private class_342 fieldSpeed;
    private class_342 fieldRange;
    private int fieldsOffsetY;
    private int modulePanelH;

    private static class Module {
        final String name;
        final int cat;
        final BooleanSupplier isOn;
        final Runnable toggle;
        Module(String name, int cat, BooleanSupplier isOn, Runnable toggle) {
            this.name = name;
            this.cat = cat;
            this.isOn = isOn;
            this.toggle = toggle;
        }
    }

    public ClickGuiScreen() {
        super(new class_2585("Котлован v2"));
    }

    private void buildModules() {
        modules = new ArrayList<>();
        // Движение (0)
        modules.add(new Module("Fly", 0, k::isFly, k::toggleFly));
        modules.add(new Module("Speed", 0, k::isSpeed, k::toggleSpeed));
        modules.add(new Module("Sprint", 0, k::isSprint, k::toggleSprint));
        modules.add(new Module("Step", 0, k::isStep, k::toggleStep));
        modules.add(new Module("Glide", 0, k::isGlide, k::toggleGlide));
        modules.add(new Module("AirJump", 0, k::isAirJump, k::toggleAirJump));
        modules.add(new Module("Spider", 0, k::isSpider, k::toggleSpider));
        modules.add(new Module("LongJump", 0, k::isLongJump, k::toggleLongJump));
        modules.add(new Module("Freecam", 0, k::isFreecam, k::toggleFreecam));
        // Комбат (1)
        modules.add(new Module("KillAura", 1, k::isKillAura, k::toggleKillAura));
        modules.add(new Module("Criticals", 1, k::isCriticals, k::toggleCriticals));
        modules.add(new Module("AutoSword", 1, k::isAutoSword, k::toggleAutoSword));
        modules.add(new Module("InstantAttack", 1, k::isInstantAttack, k::toggleInstantAttack));
        modules.add(new Module("AutoTool", 1, k::isAutoTool, k::toggleAutoTool));
        // Игрок (2)
        modules.add(new Module("NoFall", 2, k::isNoFall, k::toggleNoFall));
        modules.add(new Module("Nuker", 2, k::isNuker, k::toggleNuker));
        modules.add(new Module("ChestStealer", 2, k::isChestStealer, k::toggleChestStealer));
        // Система (3)
        modules.add(new Module("FullBright", 3, k::isFullBright, k::toggleFullBright));
        modules.add(new Module("HideHud", 3, k::isHideHud, k::toggleHideHud));
    }

    @Override
    protected void method_25426() {
        buildModules();
        panelX = 30;
        panelY = 40;
        nameField = null;
        fieldRadius = null;
        fieldSpeed = null;
        fieldRange = null;
        addButtons();
    }

    private static final int ROW_W = 130;
    private static final int ROW_H = 17;

    @Override
    public void method_25394(class_4587 matrices, int mouseX, int mouseY, float delta) {
        this.method_25420(matrices);
        this.field_22793.method_1720(matrices, "§l§bКотлован §7v2.0  §8[ПКМ/RMB=ввод|Ctrl+LMB]", 6, 6, 0xFFFFFF);

        if (modulePanelH > 0) {
            net.minecraft.class_332.method_25294(matrices,
                    panelX - 2, panelY + 22, panelX + ROW_W + 2, panelY + 24 + modulePanelH, 0xC011111A);
        }

        super.method_25394(matrices, mouseX, mouseY, delta);

        int lx = panelX + ROW_W + 26;
        int ly = fieldsOffsetY;
        if (nameField != null) {
            field_22793.method_1720(matrices, "§7Имя (NameSpoof) — пусто = выкл", lx, ly - 12, 0xFFFFFF);
            nameField.method_25394(matrices, mouseX, mouseY, delta);
            ly += 42;
        }
        if (fieldRadius != null) {
            field_22793.method_1720(matrices, "§7Радиус Nuker (1-8)", lx, ly - 12, 0xFFFFFF);
            fieldRadius.method_25394(matrices, mouseX, mouseY, delta);
            ly += 42;
        }
        if (fieldSpeed != null) {
            field_22793.method_1720(matrices, "§7Speed множитель (1-10)", lx, ly - 12, 0xFFFFFF);
            fieldSpeed.method_25394(matrices, mouseX, mouseY, delta);
            ly += 42;
        }
        if (fieldRange != null) {
            field_22793.method_1720(matrices, "§7KillAura дальность (1-10)", lx, ly - 12, 0xFFFFFF);
            fieldRange.method_25394(matrices, mouseX, mouseY, delta);
        }
    }

    private void addButtons() {
        // Категории
        int tx = panelX;
        int maxW = 0;
        for (String c : CATS) {
            int w = field_22793.method_1727(c) + 18;
            if (w > maxW) maxW = w;
        }
        for (int c = 0; c < CATS.length; c++) {
            final int cat = c;
            this.method_25411(new class_4185(tx, panelY, maxW, 18,
                    new class_2585((selectedCat == c ? "§b" : "§7") + "▌ " + CATS[c]),
                    b -> { selectedCat = cat; this.rebuild(); }));
            tx += maxW + 2;
        }

        // Модули категории
        int y = panelY + 25;
        int count = 0;
        for (Module m : modules) {
            if (m.cat != selectedCat) continue;
            count++;
            boolean on = m.isOn.getAsBoolean();
            this.method_25411(new class_4185(panelX, y, ROW_W, ROW_H,
                    new class_2585((on ? "§a" : "§7") + "▌ " + (on ? "§f" : "§8") + m.name),
                    b -> { m.toggle.run(); this.rebuild(); }));
            y += ROW_H + 2;
        }
        int moduleH = count * (ROW_H + 2) + 2;
        this.modulePanelH = moduleH;

        // Правая панель
        int sx = panelX + ROW_W + 26;
        addSettingsPanel(sx, panelY);
    }

    private void addSettingsPanel(int sx, int sy) {
        int sw = 190;

        this.method_25411(new class_4185(sx, sy, sw, 20,
                new class_2585("§c§l⚠ ТРЕВОГА ⚠"), b -> { k.panic(); this.rebuild(); }));

        this.method_25411(new class_4185(sx, sy + 24, sw, 18,
                new class_2585("§a✅ Сохранить конфиг"), b -> { k.updateConfig(); KotlovanMod.chat("Конфиг сохранён!"); }));

        int yy = sy + 52;
        fieldsOffsetY = yy;

        nameField = new class_342(field_22793, sx, yy, sw, 18, new class_2585("name"));
        nameField.method_1880(16);
        nameField.method_1852(k.getName());
        nameField.method_1863(s -> k.setName(s));
        this.method_25429(nameField);
        yy += 42;

        fieldRadius = new class_342(field_22793, sx, yy, sw, 18, new class_2585("radius"));
        fieldRadius.method_1880(4);
        fieldRadius.method_1852(String.valueOf(k.getNukerRadius()));
        fieldRadius.method_1863(s -> {
            try { k.setNukerRadius(Integer.parseInt(s.trim())); } catch (Exception ignored) { }
        });
        this.method_25429(fieldRadius);
        yy += 42;

        fieldSpeed = new class_342(field_22793, sx, yy, sw, 18, new class_2585("speed"));
        fieldSpeed.method_1880(6);
        fieldSpeed.method_1852(String.valueOf(k.getSpeedMul()));
        fieldSpeed.method_1863(s -> {
            try { k.setSpeedMul(Double.parseDouble(s.trim().replace(',', '.'))); } catch (Exception ignored) { }
        });
        this.method_25429(fieldSpeed);
        yy += 42;

        fieldRange = new class_342(field_22793, sx, yy, sw, 18, new class_2585("range"));
        fieldRange.method_1880(6);
        fieldRange.method_1852(String.valueOf(k.getKillAuraRange()));
        fieldRange.method_1863(s -> {
            try { k.setKillAuraRange(Double.parseDouble(s.trim().replace(',', '.'))); } catch (Exception ignored) { }
        });
        this.method_25429(fieldRange);
    }

    private void rebuild() {
        this.method_25423(this.field_22787, this.field_22789, this.field_22790);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (nameField != null) nameField.method_25402(mouseX, mouseY, button);
        if (fieldRadius != null) fieldRadius.method_25402(mouseX, mouseY, button);
        if (fieldSpeed != null) fieldSpeed.method_25402(mouseX, mouseY, button);
        if (fieldRange != null) fieldRange.method_25402(mouseX, mouseY, button);
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (nameField != null && nameField.method_25370()) return nameField.method_25404(keyCode, scanCode, modifiers);
        if (fieldRadius != null && fieldRadius.method_25370()) return fieldRadius.method_25404(keyCode, scanCode, modifiers);
        if (fieldSpeed != null && fieldSpeed.method_25370()) return fieldSpeed.method_25404(keyCode, scanCode, modifiers);
        if (fieldRange != null && fieldRange.method_25370()) return fieldRange.method_25404(keyCode, scanCode, modifiers);
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25400(char chr, int keyCode) {
        if (nameField != null && nameField.method_25370()) return nameField.method_25400(chr, keyCode);
        if (fieldRadius != null && fieldRadius.method_25370()) return fieldRadius.method_25400(chr, keyCode);
        if (fieldSpeed != null && fieldSpeed.method_25370()) return fieldSpeed.method_25400(chr, keyCode);
        if (fieldRange != null && fieldRange.method_25370()) return fieldRange.method_25400(chr, keyCode);
        return super.method_25400(chr, keyCode);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
