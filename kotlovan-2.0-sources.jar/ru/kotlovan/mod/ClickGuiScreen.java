package ru.kotlovan.mod;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import net.minecraft.class_2585;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;

public class ClickGuiScreen extends class_437 {

    private static final String[] CATS = {"Движение", "Комбат", "Игрок", "Рендер", "Система"};
    private static final int[] CAT_COLOR = {0x00e5ff, 0xff4d6d, 0xa3ff12, 0xffd60a, 0xff7ac8};

    private final KotlovanClient k = KotlovanMod.client();
    private int panelX;
    private int panelY;
    private int selectedCat = 0;

    private List<Module> modules;
    private class_342 nameField;
    private class_342 fieldRadius;
    private class_342 fieldSpeed;
    private class_342 fieldRange;
    private class_342 fieldTimer;
    private class_342 fieldVelocity;
    private int fieldsOffsetY;

    private static class Module {
        final String name;
        final int cat;
        final BooleanSupplier isOn;
        final Runnable toggle;
        Module(String name, int cat, BooleanSupplier isOn, Runnable toggle) {
            this.name = name;
            this.cat = cat;
            this.isOn = isOn;
            this.toggle = toggle;
        }
    }

    public ClickGuiScreen() {
        super(new class_2585("Котлован v2"));
    }

    private void buildModules() {
        modules = new ArrayList<>();
        // Движение (0)
        modules.add(new Module("Fly", 0, k::isFly, k::toggleFly));
        modules.add(new Module("Speed", 0, k::isSpeed, k::toggleSpeed));
        modules.add(new Module("Sprint", 0, k::isSprint, k::toggleSprint));
        modules.add(new Module("Step", 0, k::isStep, k::toggleStep));
        modules.add(new Module("Glide", 0, k::isGlide, k::toggleGlide));
        modules.add(new Module("Timer", 0, k::isTimer, k::toggleTimer));
        modules.add(new Module("AirJump", 0, k::isAirJump, k::toggleAirJump));
        modules.add(new Module("Spider", 0, k::isSpider, k::toggleSpider));
        modules.add(new Module("LongJump", 0, k::isLongJump, k::toggleLongJump));
        modules.add(new Module("FastLadder", 0, k::isFastLadder, k::toggleFastLadder));
        modules.add(new Module("SafeWalk", 0, k::isSafeWalk, k::toggleSafeWalk));
        modules.add(new Module("NoWeb", 0, k::isNoWeb, k::toggleNoWeb));
        modules.add(new Module("Velocity", 0, k::isVelocity, k::toggleVelocity));
        modules.add(new Module("Freecam", 0, k::isFreecam, k::toggleFreecam));
        // Комбат (1)
        modules.add(new Module("KillAura", 1, k::isKillAura, k::toggleKillAura));
        modules.add(new Module("Criticals", 1, k::isCriticals, k::toggleCriticals));
        modules.add(new Module("AutoSword", 1, k::isAutoSword, k::toggleAutoSword));
        modules.add(new Module("InstantAttack", 1, k::isInstantAttack, k::toggleInstantAttack));
        modules.add(new Module("AutoTool", 1, k::isAutoTool, k::toggleAutoTool));
        // Игрок (2)
        modules.add(new Module("NoFall", 2, k::isNoFall, k::toggleNoFall));
        modules.add(new Module("Nuker", 2, k::isNuker, k::toggleNuker));
        modules.add(new Module("ChestStealer", 2, k::isChestStealer, k::toggleChestStealer));
        // Рендер (3)
        modules.add(new Module("FullBright", 3, k::isFullBright, k::toggleFullBright));
        modules.add(new Module("ESP", 3, k::isEsp, k::toggleEsp));
        modules.add(new Module("Tracers", 3, k::isTracers, k::toggleTracers));
        modules.add(new Module("X-Ray", 3, k::isXray, k::toggleXray));
        modules.add(new Module("NoRender", 3, k::isNoRender, k::toggleNoRender));
        // Система (4)
        modules.add(new Module("HideHud", 4, k::isHideHud, k::toggleHideHud));
    }

    @Override
    protected void method_25426() {
        buildModules();
        panelX = 30;
        panelY = 46;
        nameField = null;
        fieldRadius = null;
        fieldSpeed = null;
        fieldRange = null;
        fieldTimer = null;
        fieldVelocity = null;
        addButtons();
    }

    private static final int ROW_W = 150;
    private static final int ROW_H = 18;

    @Override
    public void method_25394(class_4587 matrices, int mouseX, int mouseY, float delta) {
        this.method_25420(matrices);

        // Неоновый заголовок
        neonFill(matrices, panelX - 4, panelY - 32, panelX + 470, panelY - 28, 0xff00e5ff, 0xff00e5ff);

        this.field_22793.method_1720(matrices, "§l§bКотлован §7v2.0 §8— §7" + CATS[selectedCat],
                panelX - 2, panelY - 24, 0xFFFFFF);

        // Подложка модулей
        int count = 0;
        for (Module m : modules) if (m.cat == selectedCat) count++;
        int moduleH = count * (ROW_H + 2) + 2;
        neonFill(matrices, panelX - 4, panelY + 22, panelX + ROW_W + 2, panelY + 26 + moduleH, 0xcc0a0d18, 0xcc07101e);

        super.method_25394(matrices, mouseX, mouseY, delta);

        // Поля настроек с подписями
        int sx = panelX + ROW_W + 26;
        int ly = fieldsOffsetY;
        class_342[] fields = {nameField, fieldRadius, fieldSpeed, fieldRange, fieldTimer, fieldVelocity};
        String[] labels = {"Имя (NameSpoof): пусто = выкл", "Радиус Nuker", "Speed x", "KA Дальность", "Timer x (1-10)", "Velocity (0-1)"};
        for (int i = 0; i < fields.length; i++) {
            class_342 f = fields[i];
            if (f == null) continue;
            neonFill(matrices, sx - 6, ly - 12, sx + 186, ly + 20, 0xcc0a0d18, 0xcc07101e);
            this.field_22793.method_1720(matrices, "§7" + labels[i], sx, ly - 10, 0x88aabb);
            f.method_25394(matrices, mouseX, mouseY, delta);
            ly += 42;
        }
    }

    private void neonFill(class_4587 m, int x1, int y1, int x2, int y2, int c1, int c2) {
        net.minecraft.class_332.method_25294(m, x1, y1, x2, y2, 0x33000000);
        this.method_25296(m, x1, y1, x2, y2, c1, c2);
    }

    private void addButtons() {
        // Категории (верхняя неоновая лента)
        int tx = panelX;
        int maxW = 0;
        for (String c : CATS) {
            int w = field_22793.method_1727(c) + 20;
            if (w > maxW) maxW = w;
        }
        for (int c = 0; c < CATS.length; c++) {
            final int cat = c;
            boolean sel = selectedCat == c;
            int col = CAT_COLOR[c];
            String hex = String.format("#%06X", col);
            this.method_25411(new class_4185(tx, panelY, maxW, 18,
                    new class_2585((sel ? "§l§b" : "§7") + "▌ " + CATS[c]),
                    b -> { selectedCat = cat; this.rebuild(); }));
            tx += maxW + 2;
        }

        // Модули категории — неоновые
        int y = panelY + 25;
        int count = 0;
        for (Module m : modules) {
            if (m.cat != selectedCat) continue;
            count++;
            boolean on = m.isOn.getAsBoolean();
            String prefix = on ? "§a●" : "§8○";
            this.method_25411(new class_4185(panelX, y, ROW_W, ROW_H,
                    new class_2585(prefix + " " + (on ? "§f" : "§7") + m.name),
                    b -> { m.toggle.run(); this.rebuild(); }));
            y += ROW_H + 2;
        }

        // Правая панель: настройки + кнопки
        int sx = panelX + ROW_W + 26;
        addSettingsPanel(sx, panelY);
    }

    private void addSettingsPanel(int sx, int sy) {
        int sw = 180;

        this.method_25411(new class_4185(sx, sy, sw, 20,
                new class_2585("§c§l⚠ ТРЕВОГА ⚠"), b -> { k.panic(); this.rebuild(); }));

        this.method_25411(new class_4185(sx, sy + 24, sw, 18,
                new class_2585("§a✓ Сохранить конфиг"), b -> { k.updateConfig(); KotlovanMod.chat("Конфиг сохранён!"); }));

        int yy = sy + 54;
        fieldsOffsetY = yy;

        nameField = new class_342(field_22793, sx, yy, sw, 18, new class_2585("name"));
        nameField.method_1880(16);
        nameField.method_1852(k.getName());
        nameField.method_1863(s -> k.setName(s));
        this.method_25429(nameField);
        yy += 42;

        fieldRadius = new class_342(field_22793, sx, yy, sw, 18, new class_2585("radius"));
        fieldRadius.method_1880(4);
        fieldRadius.method_1852(String.valueOf(k.getNukerRadius()));
        fieldRadius.method_1863(s -> {
            try { k.setNukerRadius(Integer.parseInt(s.trim())); } catch (Exception ignored) { }
        });
        this.method_25429(fieldRadius);
        yy += 42;

        fieldSpeed = new class_342(field_22793, sx, yy, sw, 18, new class_2585("speed"));
        fieldSpeed.method_1880(6);
        fieldSpeed.method_1852(String.valueOf(k.getSpeedMul()));
        fieldSpeed.method_1863(s -> {
            try { k.setSpeedMul(Double.parseDouble(s.trim().replace(',', '.'))); } catch (Exception ignored) { }
        });
        this.method_25429(fieldSpeed);
        yy += 42;

        fieldRange = new class_342(field_22793, sx, yy, sw, 18, new class_2585("range"));
        fieldRange.method_1880(6);
        fieldRange.method_1852(String.valueOf(k.getKillAuraRange()));
        fieldRange.method_1863(s -> {
            try { k.setKillAuraRange(Double.parseDouble(s.trim().replace(',', '.'))); } catch (Exception ignored) { }
        });
        this.method_25429(fieldRange);
        yy += 42;

        fieldTimer = new class_342(field_22793, sx, yy, sw, 18, new class_2585("timer"));
        fieldTimer.method_1880(4);
        fieldTimer.method_1852(String.valueOf(k.getTimerMul()));
        fieldTimer.method_1863(s -> {
            try { k.setTimerMul(Integer.parseInt(s.trim())); } catch (Exception ignored) { }
        });
        this.method_25429(fieldTimer);
        yy += 42;

        fieldVelocity = new class_342(field_22793, sx, yy, sw, 18, new class_2585("velocity"));
        fieldVelocity.method_1880(4);
        fieldVelocity.method_1852(String.valueOf(k.getVelocityReduce()));
        fieldVelocity.method_1863(s -> {
            try { k.setVelocityReduce(Double.parseDouble(s.trim().replace(',', '.'))); } catch (Exception ignored) { }
        });
        this.method_25429(fieldVelocity);
    }

    private void rebuild() {
        this.method_25423(this.field_22787, this.field_22789, this.field_22790);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        class_342[] fields = {nameField, fieldRadius, fieldSpeed, fieldRange, fieldTimer, fieldVelocity};
        for (class_342 f : fields) {
            if (f != null) f.method_25402(mouseX, mouseY, button);
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        class_342[] fields = {nameField, fieldRadius, fieldSpeed, fieldRange, fieldTimer, fieldVelocity};
        for (class_342 f : fields) {
            if (f != null && f.method_25370()) return f.method_25404(keyCode, scanCode, modifiers);
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25400(char chr, int keyCode) {
        class_342[] fields = {nameField, fieldRadius, fieldSpeed, fieldRange, fieldTimer, fieldVelocity};
        for (class_342 f : fields) {
            if (f != null && f.method_25370()) return f.method_25400(chr, keyCode);
        }
        return super.method_25400(chr, keyCode);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
