package ru.kotlovan.mod.util;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_310;
import net.minecraft.class_4587;

public class RenderUtils {

    public static void drawBox(class_4587 matrices, class_238 box, float r, float g, float b, float a) {
        drawBox(matrices, box.field_1323, box.field_1322, box.field_1321, box.field_1320, box.field_1325, box.field_1324, r, g, b, a);
    }

    public static void drawBox(class_4587 matrices, double x1, double y1, double z1,
                               double x2, double y2, double z2, float r, float g, float b, float a) {
        class_310 mc = class_310.method_1551();
        class_243 cam = mc.field_1773.method_19418().method_19326();
        double dx = x1 - cam.field_1352;
        double dy = y1 - cam.field_1351;
        double dz = z1 - cam.field_1350;
        double sx = x2 - x1;
        double sy = y2 - y1;
        double sz = z2 - z1;

        RenderSystem.enableBlend();
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.lineWidth(2.0f);

        class_289 tess = class_289.method_1348();
        class_287 bb = tess.method_1349();
        bb.method_1328(1, class_290.field_1576);

        addBoxVertices(bb, dx, dy, dz, sx, sy, sz, r, g, b, a);

        bb.method_1326();
        tess.method_1350();

        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
        RenderSystem.enableCull();
    }

    private static void addBoxVertices(class_287 bb, double x, double y, double z,
                                       double w, double h, double d, float r, float g, float b, float a) {
        bb.method_22912(x, y, z).method_22915(r, g, b, a).method_1344();
        bb.method_22912(x + w, y, z).method_22915(r, g, b, a).method_1344();
        bb.method_22912(x + w, y, z).method_22915(r, g, b, a).method_1344();
        bb.method_22912(x + w, y, z + d).method_22915(r, g, b, a).method_1344();
        bb.method_22912(x + w, y, z + d).method_22915(r, g, b, a).method_1344();
        bb.method_22912(x, y, z + d).method_22915(r, g, b, a).method_1344();
        bb.method_22912(x, y, z + d).method_22915(r, g, b, a).method_1344();
        bb.method_22912(x, y, z).method_22915(r, g, b, a).method_1344();

        bb.method_22912(x, y + h, z).method_22915(r, g, b, a).method_1344();
        bb.method_22912(x + w, y + h, z).method_22915(r, g, b, a).method_1344();
        bb.method_22912(x + w, y + h, z).method_22915(r, g, b, a).method_1344();
        bb.method_22912(x + w, y + h, z + d).method_22915(r, g, b, a).method_1344();
        bb.method_22912(x + w, y + h, z + d).method_22915(r, g, b, a).method_1344();
        bb.method_22912(x, y + h, z + d).method_22915(r, g, b, a).method_1344();
        bb.method_22912(x, y + h, z + d).method_22915(r, g, b, a).method_1344();
        bb.method_22912(x, y + h, z).method_22915(r, g, b, a).method_1344();

        bb.method_22912(x, y, z).method_22915(r, g, b, a).method_1344();
        bb.method_22912(x, y + h, z).method_22915(r, g, b, a).method_1344();
        bb.method_22912(x + w, y, z).method_22915(r, g, b, a).method_1344();
        bb.method_22912(x + w, y + h, z).method_22915(r, g, b, a).method_1344();
        bb.method_22912(x + w, y, z + d).method_22915(r, g, b, a).method_1344();
        bb.method_22912(x + w, y + h, z + d).method_22915(r, g, b, a).method_1344();
        bb.method_22912(x, y, z + d).method_22915(r, g, b, a).method_1344();
        bb.method_22912(x, y + h, z + d).method_22915(r, g, b, a).method_1344();
    }

    public static void drawLine(class_4587 matrices, float x1, float y1, float z1,
                                float x2, float y2, float z2, float r, float g, float b, float a) {
        class_310 mc = class_310.method_1551();
        class_243 cam = mc.field_1773.method_19418().method_19326();
        RenderSystem.enableBlend();
        RenderSystem.disableDepthTest();
        RenderSystem.lineWidth(1.5f);

        class_289 tess = class_289.method_1348();
        class_287 bb = tess.method_1349();
        bb.method_1328(1, class_290.field_1576);

        bb.method_22912(x1 - cam.field_1352, y1 - cam.field_1351, z1 - cam.field_1350).method_22915(r, g, b, a).method_1344();
        bb.method_22912(x2 - cam.field_1352, y2 - cam.field_1351, z2 - cam.field_1350).method_22915(r, g, b, a).method_1344();

        bb.method_1326();
        tess.method_1350();

        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    public static void drawCircle(class_4587 matrices, double x, double y, double z,
                                  float radius, float r, float g, float b, float a) {
        class_310 mc = class_310.method_1551();
        class_243 cam = mc.field_1773.method_19418().method_19326();
        RenderSystem.enableBlend();
        RenderSystem.disableDepthTest();
        RenderSystem.lineWidth(1.5f);

        class_289 tess = class_289.method_1348();
        class_287 bb = tess.method_1349();
        bb.method_1328(1, class_290.field_1576);

        int segments = 64;
        for (int i = 0; i < segments; i++) {
            double angle1 = 2 * Math.PI * i / segments;
            double angle2 = 2 * Math.PI * (i + 1) / segments;
            bb.method_22912(x + Math.cos(angle1) * radius - cam.field_1352, y - cam.field_1351, z + Math.sin(angle1) * radius - cam.field_1350)
                    .method_22915(r, g, b, a).method_1344();
            bb.method_22912(x + Math.cos(angle2) * radius - cam.field_1352, y - cam.field_1351, z + Math.sin(angle2) * radius - cam.field_1350)
                    .method_22915(r, g, b, a).method_1344();
        }

        bb.method_1326();
        tess.method_1350();

        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    public static void drawRect(float x, float y, float w, float h, int color) {
        float a = (color >> 24 & 0xFF) / 255.0f;
        float r = (color >> 16 & 0xFF) / 255.0f;
        float g = (color >> 8 & 0xFF) / 255.0f;
        float b = (color & 0xFF) / 255.0f;

        RenderSystem.enableBlend();
        RenderSystem.disableTexture();
        RenderSystem.color4f(r, g, b, a);

        class_289 tess = class_289.method_1348();
        class_287 bb = tess.method_1349();
        bb.method_1328(7, class_290.field_1576);

        bb.method_22912(x, y, 0).method_22915(r, g, b, a).method_1344();
        bb.method_22912(x, y + h, 0).method_22915(r, g, b, a).method_1344();
        bb.method_22912(x + w, y + h, 0).method_22915(r, g, b, a).method_1344();
        bb.method_22912(x + w, y, 0).method_22915(r, g, b, a).method_1344();

        bb.method_1326();
        tess.method_1350();

        RenderSystem.enableTexture();
        RenderSystem.disableBlend();
    }

    public static void drawGradientRect(float x, float y, float w, float h, int topColor, int bottomColor) {
        RenderSystem.enableBlend();
        RenderSystem.disableTexture();

        float ta = (topColor >> 24 & 0xFF) / 255.0f;
        float tr = (topColor >> 16 & 0xFF) / 255.0f;
        float tg = (topColor >> 8 & 0xFF) / 255.0f;
        float tb = (topColor & 0xFF) / 255.0f;

        float ba2 = (bottomColor >> 24 & 0xFF) / 255.0f;
        float br = (bottomColor >> 16 & 0xFF) / 255.0f;
        float bg = (bottomColor >> 8 & 0xFF) / 255.0f;
        float bb2 = (bottomColor & 0xFF) / 255.0f;

        class_289 tess = class_289.method_1348();
        class_287 buf = tess.method_1349();
        buf.method_1328(7, class_290.field_1576);

        buf.method_22912(x, y, 0).method_22915(tr, tg, tb, ta).method_1344();
        buf.method_22912(x, y + h, 0).method_22915(br, bg, bb2, ba2).method_1344();
        buf.method_22912(x + w, y + h, 0).method_22915(br, bg, bb2, ba2).method_1344();
        buf.method_22912(x + w, y, 0).method_22915(tr, tg, tb, ta).method_1344();

        buf.method_1326();
        tess.method_1350();

        RenderSystem.enableTexture();
        RenderSystem.disableBlend();
    }
}
